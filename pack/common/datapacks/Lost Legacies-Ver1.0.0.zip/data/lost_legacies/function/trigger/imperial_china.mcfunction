tag @s add ll_used
summon minecraft:zombie_villager ~ ~ ~ {equipment:{mainhand:{id:"minecraft:iron_spear",count:1}},IsBaby:0b}
execute positioned ~ ~ ~ as @e[type=minecraft:zombie_villager,distance=..1.5,limit=1,sort=nearest] at @s run function lost_legacies:configure/imperial_china
