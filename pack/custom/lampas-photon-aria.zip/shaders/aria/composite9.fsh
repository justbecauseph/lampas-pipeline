#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_ARIA
#define BLOOM_TILE_INDEX 4
#define fsh
#include "/program/c5_c10_bloom_downsample.fsh"
