#version 330 compatibility

#define PARALLAX_MOTION_VECTOR_FIX // Prevents parallax from creating false motion vectors and temporal flicker. Disable for comparison with the original behavior.
#extension GL_ARB_gpu_shader5 : enable

/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
		) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/

















in vec4 color;
in vec4 texcoord;
in vec4 lmcoord;
in vec3 worldPosition;
in vec3 viewPos;
in vec4 preDownscaleProjPos;
in vec4 glPosition;

in vec3 worldNormal;

in vec2 blockLight;

in float materialIDs;


in mat3 tbnMatrix;
in vec3 tangent;
in vec3 binormal;
in vec3 normal;





#include "lib/Uniforms.inc"
#include "lib/Common.inc"
#include "lib/GBufferData.inc"
#include "lib/GBuffersCommon.inc"

vec2 AtlasTiles;
float TextureTexel;


vec2 OffsetCoord(in vec2 coord, in vec2 offset)
{
	vec2 interTileCoord = fract(coord + offset);
	return (floor(coord) + interTileCoord) / AtlasTiles;
}

float BilinearHeightSample(vec2 coord) {
	vec2 fpc = fract(coord * vec2(atlasSize) + 0.5);
	coord *= AtlasTiles;

	vec4 sh;
	sh = vec4(
		texture2DLod(normals, OffsetCoord(coord, vec2(-TextureTexel,  TextureTexel)), 0).a,
		texture2DLod(normals, OffsetCoord(coord, vec2( TextureTexel,  TextureTexel)), 0).a,
		texture2DLod(normals, OffsetCoord(coord, vec2( TextureTexel, -TextureTexel)), 0).a,
		texture2DLod(normals, OffsetCoord(coord, vec2(-TextureTexel, -TextureTexel)), 0).a
	);

	return mix(
		mix(sh.w, sh.z, fpc.x),
		mix(sh.x, sh.y, fpc.x),
		fpc.y
	);
}

vec2 CalculateParallaxCoord(vec2 coord, vec3 viewVector, vec2 texGradX, vec2 texGradY, out vec3 offsetCoord)
{
	vec2 parallaxCoord = coord.st;
	vec3 stepScale = vec3(0.15, 0.15, 0.15);

	float parallaxDepth = PARALLAX_DEPTH * 0.2;

	const float gradThreshold = 0.01 * PARALLAX_DISTANCE;
	float absoluteTexGrad = dot(abs(texGradX) + abs(texGradY), vec2(1.0));

	parallaxDepth *= 1.0 - saturate(absoluteTexGrad / gradThreshold);
	if (absoluteTexGrad > gradThreshold)
	{
		offsetCoord = vec3(0.0, 0.0, 1.0);
		return texcoord.st;
	}

	float parallaxStepSize = 0.5;

	stepScale.xy *= parallaxDepth;
	stepScale *= parallaxStepSize;

	#ifdef SMOOTH_PARALLAX
	float heightmap = BilinearHeightSample(coord.xy);
	#else
	float heightmap = textureGrad(normals, coord.st, texGradX, texGradY).a;
	#endif

	vec3 pCoord = vec3(0.0f, 0.0f, 1.0f);
	vec2 basicCoord = coord.xy * AtlasTiles;

	if (heightmap < 1.0)
	{
		const int maxRefinements = 4;
		int numRefinements = 0;

		vec3 stepSize = viewVector * stepScale * 0.25 * (absoluteTexGrad * 15500.0 + 1.0);
		stepSize.xy *= AtlasTiles;
		float sampleHeight = heightmap;

		for (int i = 0; i < 80; i++)
		{
			pCoord += stepSize;

			parallaxCoord = OffsetCoord(basicCoord, pCoord.xy);

			#ifdef SMOOTH_PARALLAX
			sampleHeight = BilinearHeightSample(parallaxCoord);
			#else
			sampleHeight = textureGrad(normals, parallaxCoord, texGradX, texGradY).a;
			#endif

			if (sampleHeight > pCoord.z)
			{
				if (numRefinements < maxRefinements)
				{
					pCoord -= stepSize;
					stepSize *= 0.5;
					numRefinements++;
				}
				else
				{
					break;
				}
			}
		}
	}
	pCoord.xy /= AtlasTiles;
	offsetCoord = pCoord;

	return parallaxCoord;
}




void main() 
{	
	if (PixelOutOfScreenBounds(preDownscaleProjPos)) {
		discard;
		return;
	}
	float lodOffset = 0.0;

	float gradMult = 1.0 / TEXTURE_LOD_BIAS;

	vec2 texGradX = dFdx(texcoord.st) * gradMult;
	vec2 texGradY = dFdy(texcoord.st) * gradMult;

	#ifdef ANISOTROPIC_LOD_BIAS
	if (length(texGradX) < length(texGradY)) {
		texGradY = texGradX;
	} else {
		texGradX = texGradY;
	}
	#endif

	vec2 textureCoordinate = texcoord.st;





	vec3 N;
	mat3 tbn;
	mat3 tbnRaw;
	CalculateNormalAndTBN(viewPos.xyz, texcoord.st, N, tbn, tbnRaw);

	#ifdef PARALLAX
		AtlasTiles = vec2(atlasSize) / TEXTURE_RESOLUTION;
		TextureTexel = 0.5 / TEXTURE_RESOLUTION;

		vec3 texViewVector = tbnRaw * viewPos.xyz;
		texViewVector.xy *= TEXTURE_RESOLUTION / vec2(atlasSize);
		texViewVector = normalize(texViewVector);

		vec3 offsetCoord;
		textureCoordinate = CalculateParallaxCoord(texcoord.st, texViewVector, texGradX, texGradY, offsetCoord);
	#endif
	
	// #ifndef SKIP_AA
	// vec3 dither = BlueNoiseTemporal(abs(glPosition.xy / glPosition.w) * 1.0).rgb;
	// textureCoordinate = OffsetCoord(textureCoordinate, dither.x * texGradX * 1.0 + dither.y * texGradY * 1.0, 0);
	// #endif


	// vec4 albedo = GetSourceTexture(texture, textureCoordinate);

	vec4 albedo = textureGrad(texture, textureCoordinate, texGradX, texGradY);










	albedo *= color;

	vec2 mcLightmap = blockLight;



	float wetnessModulator = 1.0;

	vec3 rainNormal = vec3(0.0, 0.0, 0.0);
	#ifdef RAIN_SPLASH_EFFECT
	rainNormal = GetRainSplashNormal(worldPosition, worldNormal, wetnessModulator);
	#endif

	wetnessModulator *= saturate(worldNormal.y * 10.5 + 0.7);
	wetnessModulator *= saturate(abs(2.0 - materialIDs));
	wetnessModulator *= clamp(blockLight.y * 1.05 - 0.7, 0.0, 0.3) / 0.3;
	wetnessModulator *= saturate(wetness * 1.1 - 0.1);








	vec4 specTex = textureGrad(specular, textureCoordinate, texGradX, texGradY);
	#ifdef SPEC_SMOOTHNESS_AS_ROUGHNESS
	specTex.SPEC_CHANNEL_SMOOTHNESS = 1.0 - specTex.SPEC_CHANNEL_SMOOTHNESS;
	#endif
	specTex.SPEC_CHANNEL_SMOOTHNESS = specTex.SPEC_CHANNEL_SMOOTHNESS * 0.992; 								// Fix weird specular issue
	

	vec4 normalTex = textureGrad(normals, textureCoordinate, texGradX, texGradY) * 2.0 - 1.0;
	normalTex.xy = sign(normalTex.xy) * max(vec2(0.0), abs(normalTex.xy) - 0.003);

	float normalMapStrength = NORMAL_MAP_STRENGTH;
	#ifdef FORCE_WET_EFFECT
	normalMapStrength = mix(NORMAL_MAP_STRENGTH, 0.1, wetnessModulator * wetnessModulator * wetnessModulator * wetnessModulator);


	vec3 viewNormal = tbn * normalize(normalTex.xyz * vec3(normalMapStrength, normalMapStrength, 1.0) + rainNormal * wetnessModulator);
	#else
	// normalTex is already computed above (line 265) - do not redeclare it here,
	// that caused a duplicate-declaration compile error whenever FORCE_WET_EFFECT
	// was disabled, killing the whole gbuffers_terrain program.
	vec3 viewNormal;
	{
		const float eps = 0.00001;
		float cD = BilinearHeightSample(textureCoordinate);
		float rD = BilinearHeightSample(textureCoordinate + vec2(eps, 0.0));
		float uD = BilinearHeightSample(textureCoordinate + vec2(0.0, eps));

		float xDiff = (cD - rD) / eps;
		float yDiff = (cD - uD) / eps;

		vec3 heightNormal = normalize(vec3(2.0 * xDiff, 2.0 * yDiff, -4.0));

		viewNormal = tbn * heightNormal;
	}
	#endif
	
	// Get specular data from specular texture
	float smoothness = specTex.SPEC_CHANNEL_SMOOTHNESS;
	float metallic = specTex.SPEC_CHANNEL_METALNESS;
	float emissive = specTex.SPEC_CHANNEL_EMISSIVE;
	// Fix false-positive emissive on resource packs whose specular texture has no real
	// emissive data: an untouched channel commonly sits at 1.0 (fully opaque/white),
	// which would otherwise read as "fully emissive" everywhere.
	emissive -= step(0.999, emissive);

	#ifdef FORCE_WET_EFFECT
	if (isEyeInWater < 1)
	{
		smoothness = mix(smoothness, 1.0, saturate(wetnessModulator * 1.0 * saturate(1.0 - metallic)));
	}
	#endif

	// Darker albedo when wet
	albedo.rgb = pow(albedo.rgb, vec3(1.0 + wetnessModulator * (1.0 - metallic) * 0.1));




	// Fix impossible normal angles
	vec3 viewDir = -normalize(viewPos.xyz);
	vec3 relfectDir = reflect(-viewDir, viewNormal);
	// make outright impossible
	viewNormal.xyz = normalize(viewNormal.xyz + (N / (pow(saturate(dot(viewNormal, viewDir)) + 0.001, 0.5)) * 1.0));





	// vec3 analyticNormal = normalize(cross(dFdx(viewPos.xyz), dFdy(viewPos.xyz)));

	// albedo.rgb = analyticNormal.xyz * 0.5 + 0.5;
	// albedo.rgb *= 0.5;
	// albedo.rgb = vec3(0.1);
	// smoothness = 0.0;
	// metallic = 0.0;


	// metallic += 0.2;

	#ifdef WET_CAVE_EFFECT
	float caveDamp = 1.0 - metallic;
	caveDamp *= pow((1.0 - mcLightmap.y), 2.0);
	caveDamp *= pow((1.0 - mcLightmap.x), 1.0);
	smoothness = mix(smoothness, 1.0, 0.9 * caveDamp);
	#endif




	GBufferData gbuffer;
	gbuffer.albedo = albedo * 1.0;
	gbuffer.normal = viewNormal.xyz;
	gbuffer.mcLightmap = mcLightmap;
	gbuffer.smoothness = smoothness;
	gbuffer.metalness = metallic;
	gbuffer.materialID = (materialIDs + 0.1) / 255.0;
	gbuffer.emissive = saturate(emissive);
	#ifndef SPEC_EMISSIVE
	gbuffer.emissive = 0.0;
	#endif
	gbuffer.geoNormal = N.xyz;
	gbuffer.totalTexGrad = length(fwidth(texcoord.st)) * (256.0 / 8.0);




	// vec3 worldPos = (gbufferModelViewInverse * vec4(viewPos.xyz, 1.0)).xyz;
	// vec3 worldPosC = (gbufferModelViewInverse * vec4(viewPos.xyz, 1.0)).xyz;
	// vec3 worldViewDir = normalize(worldPosC.xyz);

	// vec3 modifiedViewPos = (gbufferModelView * vec4(worldPos.xyz, 1.0)).xyz;


	// #ifdef PARALLAX
	// 	float NdotV = dot(worldNormal.xyz, -worldViewDir);

	// 	worldPos += normalize(worldPos) * (1.0 - offsetCoord.z) * 0.2 / (saturate(NdotV) + 0.00001);
	// 	modifiedViewPos = (gbufferModelView * vec4(worldPos.xyz, 1.0)).xyz;
	// #endif

	// vec4 projPos = gbufferProjection * vec4(modifiedViewPos.xyz, 1.0);
	// projPos /= projPos.w;
	// projPos = projPos * 0.5 + 0.5;

	// #ifdef PARALLAX
	// 	gl_FragDepth = projPos.z;
	// 	gbuffer.parallaxOffset = (1.0 - offsetCoord.z);
	// #else
	// 	gbuffer.parallaxOffset = 0.0;
	// #endif





	vec3 fuckingViewDir = normalize(viewPos.xyz);

	vec3 modifiedViewPos = viewPos.xyz;


	#ifdef PARALLAX
		float NdotV = dot(normal.xyz, -fuckingViewDir);

		modifiedViewPos += fuckingViewDir * (1.0 - offsetCoord.z) * 0.2 / (saturate(NdotV) + 0.00001);
	#endif

	vec4 projPos = gbufferProjection * vec4(modifiedViewPos.xyz, 1.0);
	projPos /= projPos.w;
	projPos = projPos * 0.5 + 0.5;

	#ifdef PARALLAX
		gl_FragDepth = projPos.z;
		gbuffer.parallaxOffset = (1.0 - offsetCoord.z);
	#else
		gbuffer.parallaxOffset = 0.0;
	#endif


	vec3 worldPos = (gbufferModelViewInverse * vec4(modifiedViewPos.xyz, 1.0)).xyz;


	#ifdef PARALLAX_MOTION_VECTOR_FIX
	// Parallax is a view-dependent sub-pixel surface displacement. Do not feed
	// that displacement into the motion-vector calculation: the previous frame
	// has no matching parallax intersection, which can create huge false motion
	// vectors (especially near the top/edge of the screen) and make motion blur
	// / temporal filtering flicker. Keep the parallax-adjusted position for depth
	// and lighting, but calculate velocity from the underlying geometry position.
	{
		vec3 motionWorldPos = (gbufferModelViewInverse * vec4(viewPos.xyz, 1.0)).xyz;
		vec4 worldPosPrev = vec4(motionWorldPos + cameraPosition - previousCameraPosition, 1.0);
		vec4 viewPosPrev = gbufferPreviousModelView * worldPosPrev;
		vec4 projPosPrev = gbufferPreviousProjection * vec4(viewPosPrev.xyz, 1.0);
		projPosPrev.xyz /= projPosPrev.w;
		projPosPrev = projPosPrev * 0.5 + 0.5;

		vec4 motionProjPos = gbufferProjection * vec4(viewPos.xyz, 1.0);
		motionProjPos /= motionProjPos.w;
		motionProjPos = motionProjPos * 0.5 + 0.5;

		gbuffer.motion = (motionProjPos.xyz - projPosPrev.xyz);
	}
	#else
	// Original behavior: motion vectors use the parallax-adjusted position.
	{
		vec3 worldPosPrev = worldPos + cameraPosition - previousCameraPosition;
		vec4 viewPosPrev = gbufferPreviousModelView * vec4(worldPosPrev, 1.0);
		vec4 projPosPrev = gbufferPreviousProjection * vec4(viewPosPrev.xyz, 1.0);
		projPosPrev.xyz /= projPosPrev.w;
		projPosPrev = projPosPrev * 0.5 + 0.5;

		gbuffer.motion = (projPos.xyz - projPosPrev.xyz);
	}
	#endif





	vec4 frag0, frag1, frag2, frag3;

	OutputGBufferDataSolid(gbuffer, frag0, frag1, frag2, frag3);

	gl_FragData[0] = frag0;
	gl_FragData[1] = frag1;
	gl_FragData[2] = frag2;
	gl_FragData[3] = frag3;

}

/* RENDERTARGETS: 0,1,2,8 */
