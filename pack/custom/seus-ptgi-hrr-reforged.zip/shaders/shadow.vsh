#version 330 compatibility


#include "lib/Uniforms.inc"
#include "lib/Common.inc"
// Photon-style waving plants (see file for details)
#include "lib/PhotonWind.inc"


#define WIND_EFFECT 0.35 // [0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50]
// Controls how fast the shadows cast by grass/flowers/leaves/wheat/vines sway,
// Uses the same WIND_EFFECT setting as the visible vegetation so
// the foliage movement and its shadow stay synchronized.
// Only applies to foliage (grass, flowers, tall grass, leaves, wheat, vines) -
// see the explicit block whitelist further down in this file.

// Photon-style waving plants (lib/PhotonWind.inc) are mirrored in this file too, so
// their shadows sway exactly like the plants. They ignore WIND_EFFECT, but they do
// honor OUTDOOR_WIND_ONLY (handled inside PwPlantDisplacement itself), so shadow
// sway stays in lockstep with the plant when the option is toggled either way.

#define WIND_EFFECT_ENABLED // Must be kept in sync with gbuffers_terrain.vsh:
// master switch - disable to stop ALL wind sway (and its shadow) completely.

#define OUTDOOR_WIND_ONLY // Must be kept in sync with gbuffers_terrain.vsh: gates
// shadow-pass sway by the same per-vertex sky light value, so a plant's
// shadow is disabled/reduced in exact lockstep with the plant itself.

attribute vec4 mc_Entity;
attribute vec4 at_tangent;
attribute vec4 mc_midTexCoord;

out vec4 vTexcoord;
out vec4 vColor;
// out vec4 lmcoord;

// out vec3 normal;
out vec4 vViewPos;
out float vMaterialIDs;

out float vMCEntity;
// out float isWater;
// out float isStainedGlass;

out float NfBQQONGIL;		
out float oKoDrswuAC;			
out float GgEUdJcgVD;			
out vec2 iqqNEmzHrA;			

out vec4 zoZckPcbco;		
out vec4 RrnawHBGMh;		
out vec3 MHKfCXtBYe;        



 int f(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-0;
 }
 int t(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-1;
 }
 int f()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int x=v.x*v.y;
   return f(FloorToInt(floor(pow(float(x),.333333))));
 }
 int t()
 {
   ivec2 v=ivec2(2048,2048);
   int x=v.x*v.y;
   return t(FloorToInt(floor(pow(float(x),.333333))));
 }
 vec3 d(vec2 v)
 {
   ivec2 x=ivec2(viewWidth,viewHeight);
   int s=x.x*x.y,y=f();
   ivec2 n=ivec2(v.x*x.x,v.y*x.y);
   float z=float(n.y/y),i=float(int(n.x+mod(x.x*z,y))/y);
   i+=floor(x.x*z/y);
   vec3 m=vec3(0.,0.,i);
   m.x=mod(n.x+mod(x.x*z,y),y);
   m.y=mod(n.y,y);
   m.xyz=floor(m.xyz);
   m/=y;
   m.xyz=m.xzy;
   return m;
 }
 vec2 x(vec3 v)
 {
   ivec2 x=ivec2(viewWidth,viewHeight);
   int y=f();
   vec3 i=v.xzy*y;
   i=floor(i+1e-05);
   float s=i.z;
   vec2 n;
   n.x=mod(i.x+s*y,x.x);
   float m=i.x+s*y;
   n.y=i.y+floor(m/x.x)*y;
   n+=.5;
   n/=x;
   return n;
 }
 vec3 n(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 x=ivec2(2048,2048);
   int s=x.x*x.y,y=t();
   ivec2 n=ivec2(i.x*x.x,i.y*x.y);
   float z=float(n.y/y),f=float(int(n.x+mod(x.x*z,y))/y);
   f+=floor(x.x*z/y);
   vec3 m=vec3(0.,0.,f);
   m.x=mod(n.x+mod(x.x*z,y),y);
   m.y=mod(n.y,y);
   m.xyz=floor(m.xyz);
   m/=y;
   m.xyz=m.xzy;
   return m;
 }
 vec2 d(vec3 v,int y)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   vec2 x=vec2(2048,2048);
   vec3 i=v.xzy*y;
   i=floor(i+1e-05);
   float s=i.z;
   vec2 n;
   n.x=mod(i.x+s*y,x.x);
   float m=i.x+s*y;
   n.y=i.y+floor(m/x.x)*y;
   n+=.5;
   n/=x;
   n.xy*=.5;
   return n;
 }
 vec3 f(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 n(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v;
 }
 vec3 v(vec3 v)
 {
   int x=t();
   v=v-vec3(.5);
   v*=x;
   return v;
 }
 vec3 r(vec3 v)
 {
   int x=f();
   v*=1./x;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 s(vec3 v)
 {
   int x=f();
   v=v-vec3(.5);
   v*=x;
   return v;
 }
 vec3 d()
 {
   vec3 x=cameraPosition.xyz+.5,v=previousCameraPosition.xyz+.5,y=floor(x-.0001),s=floor(v-.0001);
   return y-s;
 }
 vec3 m(vec3 v)
 {
   vec4 x=vec4(v,1.);
   x=shadowModelView*x;
   x=shadowProjection*x;
   x/=x.w;
   float s=sqrt(x.x*x.x+x.y*x.y),y=1.f-SHADOW_MAP_BIAS+s*SHADOW_MAP_BIAS;
   x.xy*=.95f/y;
   x.z=mix(x.z,.5,.8);
   x=x*.5f+.5f;
   x.xy*=.5;
   x.xy+=.5;
   return x.xyz;
 }
 vec3 d(vec3 v,vec3 m,vec2 x,vec2 y,vec4 n,vec4 i,inout float s,out vec2 f)
 {
   bool r=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   r=!r;
   if(i.x==8||i.x==9||i.x==79||i.x<1.||!r||i.x==20.||i.x==171.||min(abs(m.x),abs(m.z))>.2)
     s=1.;
   if(i.x==50.||i.x==52.||i.x==76.||i.x==75.||i.x==74.||i.x==72.)
     {
       s=0.;
       if(m.y<.5)
         s=1.;
     }
   if(i.x==51||i.x==53)
     s=0.;
   if(i.x>255)
     s=0.;
   vec3 z,e;
   if(m.x>.5)
     z=vec3(0.,0.,-1.),e=vec3(0.,-1.,0.);
   else
      if(m.x<-.5)
       z=vec3(0.,0.,1.),e=vec3(0.,-1.,0.);
     else
        if(m.y>.5)
         z=vec3(1.,0.,0.),e=vec3(0.,0.,1.);
       else
          if(m.y<-.5)
           z=vec3(1.,0.,0.),e=vec3(0.,0.,-1.);
         else
            if(m.z>.5)
             z=vec3(1.,0.,0.),e=vec3(0.,-1.,0.);
           else
              if(m.z<-.5)
               z=vec3(-1.,0.,0.),e=vec3(0.,-1.,0.);
   f=clamp((x.xy-y.xy)*100000.,vec2(0.),vec2(1.));
   float h=.15,o=.15;
   if(i.x==10.||i.x==11.)
     {
       // wall-mounted torches (copper/redstone): the flame top is tilted ~22.5 deg, so it failed the flat-top test
       // and was never written into the light volume -> very dim light. Accept tilted, non-block-aligned tops.
       bool tiltedTorchTop=m.y>.85&&m.y<=.99&&(fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99);
       if(abs(m.y)<.01&&r||m.y>.99||tiltedTorchTop)
         h=.1,o=.1,s=0.;
       else
          s=1.;
     }
   if(i.x==51||i.x==53)
     h=.5,o=.1;
   if(i.x==76)
     h=.2,o=.2;
   if(i.x-255.+39.>=103.&&i.x-255.+39.<=113.)
     o=.025,h=.025;
   z=normalize(n.xyz);
   e=normalize(cross(z,m.xyz)*sign(n.w));
   vec3 G=v.xyz+mix(z*h,-z*h,vec3(f.x));
   G.xyz+=mix(e*h,-e*h,vec3(f.y));
   G.xyz-=m.xyz*o;
   return G;
 }struct SPcacsgCKo{vec3 GadGLQcpqX;vec3 GadGLQcpqXOrigin;vec3 vAdYwconYe;vec3 AZVxALDdtL;vec3 UekatYTTmj;vec3 OmcxSfXfkJ;};
 SPcacsgCKo p(Ray v)
 {
   SPcacsgCKo i;
   i.GadGLQcpqX=floor(v.origin);
   i.GadGLQcpqXOrigin=i.GadGLQcpqX;
   i.vAdYwconYe=abs(vec3(length(v.direction))/(v.direction+1e-07));
   i.AZVxALDdtL=sign(v.direction);
   i.UekatYTTmj=(sign(v.direction)*(i.GadGLQcpqX-v.origin)+sign(v.direction)*.5+.5)*i.vAdYwconYe;
   i.OmcxSfXfkJ=vec3(0.);
   return i;
 }
 void e(inout SPcacsgCKo v)
 {
   v.OmcxSfXfkJ=step(v.UekatYTTmj.xyz,v.UekatYTTmj.yzx)*step(v.UekatYTTmj.xyz,v.UekatYTTmj.zxy),v.UekatYTTmj+=v.OmcxSfXfkJ*v.vAdYwconYe,v.GadGLQcpqX+=v.OmcxSfXfkJ*v.AZVxALDdtL;
 }
 void d(in Ray v,in vec3 m[2],out float x,out float i)
 {
   float y,z,s,f;
   x=(m[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   i=(m[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   y=(m[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   z=(m[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   s=(m[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   f=(m[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   x=max(max(x,y),s);
   i=min(min(i,z),f);
 }
 vec3 d(const vec3 v,const vec3 x,vec3 y)
 {
   const float s=1e-05;
   vec3 z=(x+v)*.5,i=(x-v)*.5,m=y-z,f=vec3(0.);
   f+=vec3(sign(m.x),0.,0.)*step(abs(abs(m.x)-i.x),s);
   f+=vec3(0.,sign(m.y),0.)*step(abs(abs(m.y)-i.y),s);
   f+=vec3(0.,0.,sign(m.z))*step(abs(abs(m.z)-i.z),s);
   return normalize(f);
 }
 bool e(const vec3 v,const vec3 m,Ray i,out vec2 y)
 {
   vec3 x=i.inv_direction*(v-i.origin),s=i.inv_direction*(m-i.origin),n=min(s,x),f=max(s,x);
   vec2 r=max(n.xx,n.yz);
   float z=max(r.x,r.y);
   r=min(f.xx,f.yz);
   float e=min(r.x,r.y);
   y.x=z;
   y.y=e;
   return e>max(z,0.);
 }
 bool d(const vec3 v,const vec3 m,Ray i,inout float x,inout vec3 y)
 {
   vec3 s=i.inv_direction*(v-1e-05-i.origin),z=i.inv_direction*(m+1e-05-i.origin),n=min(z,s),f=max(z,s);
   vec2 r=max(n.xx,n.yz);
   float h=max(r.x,r.y);
   r=min(f.xx,f.yz);
   float e=min(r.x,r.y);
   bool G=e>max(h,0.)&&max(h,0.)<x;
   if(G)
     y=d(v-1e-05,m+1e-05,i.origin+i.direction*h),x=h;
   return G;
 }
 vec3 e(vec3 v,vec3 i,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 n=m(v);
   float s=.5;
   vec3 f=vec3(1.)*shadow2DLod(shadowtex0,vec3(n.xy,n.z-.0006*s),2).x;
   f*=saturate(dot(i,y));
   {
     vec4 r=texture2DLod(shadowcolor1,n.xy-vec2(0.,.5),4);
     float e=abs(r.x*256.-(v.y+cameraPosition.y)),h=GetCausticsComposite(v,i,e),o=shadow2DLod(shadowtex0,vec3(n.xy-vec2(0.,.5),n.z+1e-06),4).x;
     f=mix(f,f*h,1.-o);
   }
   f=TintUnderwaterDepth(f);
   return f*(1.-rainStrength);
 }
 vec3 f(vec3 x,vec3 i,vec3 y,vec3 z,int f)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 s=v(x);
   s+=1.;
   s-=Fract01(cameraPosition+.5);
   vec3 n=m(s+y*.99);
   float h=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(n.xy,n.z-.0006*h),3).x;
   r*=saturate(dot(i,y));
   r=TintUnderwaterDepth(r);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float e=shadow2DLod(shadowtex0,vec3(n.xy-vec2(.5,0.),n.z-.0006*h),3).x;
   vec3 G=texture2DLod(shadowcolor,vec2(n.xy-vec2(.5,0.)),3).xyz;
   G*=G;
   r=mix(r,r*G,vec3(1.-e));
   #endif
   return r*(1.-rainStrength);
 }
 vec3 m(vec3 v,vec3 x,vec3 y,vec3 i,int f)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 n=m(v);
   float s=.5;
   vec3 z=vec3(1.)*shadow2DLod(shadowtex0,vec3(n.xy,n.z-.0006*s),2).x;
   z*=saturate(dot(x,y));
   z=TintUnderwaterDepth(z);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float r=shadow2DLod(shadowtex0,vec3(n.xy-vec2(.5,0.),n.z-.0006*s),3).x;
   vec3 e=texture2DLod(shadowcolor,vec2(n.xy-vec2(.5,0.)),3).xyz;
   e*=e;
   z=mix(z,z*e,vec3(1.-r));
   #endif
   return z*(1.-rainStrength);
 }struct CPrmwMXxJc{float pzBOsrqcFy;float ivaOqoXyFu;float OxTKjfMYEH;float avjkUoKnfB;vec3 PVAMAgODVh;};
 vec4 G(CPrmwMXxJc v)
 {
   vec4 i;
   v.PVAMAgODVh=max(vec3(0.),v.PVAMAgODVh);
   i.x=v.pzBOsrqcFy;
   v.PVAMAgODVh=pow(v.PVAMAgODVh,vec3(.125));
   i.y=PackTwo16BitTo32Bit(v.PVAMAgODVh.x,v.OxTKjfMYEH);
   i.z=PackTwo16BitTo32Bit(v.PVAMAgODVh.y,v.avjkUoKnfB);
   i.w=PackTwo16BitTo32Bit(v.PVAMAgODVh.z,v.ivaOqoXyFu/255.);
   return i;
 }
 CPrmwMXxJc i(vec4 v)
 {
   CPrmwMXxJc i;
   vec2 x=UnpackTwo16BitFrom32Bit(v.y),n=UnpackTwo16BitFrom32Bit(v.z),y=UnpackTwo16BitFrom32Bit(v.w);
   i.pzBOsrqcFy=v.x;
   i.OxTKjfMYEH=x.y;
   i.avjkUoKnfB=n.y;
   i.ivaOqoXyFu=y.y*255.;
   i.PVAMAgODVh=pow(vec3(x.x,n.x,y.x),vec3(8.));
   return i;
 }
 CPrmwMXxJc w(vec2 v)
 {
   vec2 x=1./vec2(viewWidth,viewHeight),y=vec2(viewWidth,viewHeight);
   v=(floor(v*y)+.5)*x;
   return i(texture2DLod(colortex5,v,0));
 }
 float G(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 bool G(vec3 v,float x,Ray y,bool m,inout float i,inout vec3 f)
 {
   bool s=false,r=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(m)
     return false;
   if(x>=67.)
     return false;
   r=d(v,v+vec3(1.,1.,1.),y,i,f);
   s=r;
   #else
   if(x<40.)
     return r=d(v,v+vec3(1.,1.,1.),y,i,f),r;
   if(x==40.||x==41.||x>=43.&&x<=54.)
     {
       float z=.5;
       if(x==41.)
         z=.9375;
       r=d(v+vec3(0.,0.,0.),v+vec3(1.,z,1.),y,i,f);
       s=s||r;
     }
   if(x==42.||x>=55.&&x<=66.)
     r=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),y,i,f),s=s||r;
   if(x==43.||x==46.||x==47.||x==52.||x==53.||x==54.||x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
     {
       float z=.5;
       if(x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
         z=0.;
       r=d(v+vec3(0.,z,0.),v+vec3(.5,.5+z,.5),y,i,f);
       s=s||r;
     }
   if(x==43.||x==45.||x==48.||x==51.||x==53.||x==54.||x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
     {
       float z=.5;
       if(x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
         z=0.;
       r=d(v+vec3(.5,z,0.),v+vec3(1.,.5+z,.5),y,i,f);
       s=s||r;
     }
   if(x==44.||x==45.||x==49.||x==51.||x==52.||x==54.||x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
     {
       float z=.5;
       if(x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
         z=0.;
       r=d(v+vec3(.5,z,.5),v+vec3(1.,.5+z,1.),y,i,f);
       s=s||r;
     }
   if(x==44.||x==46.||x==50.||x==51.||x==52.||x==53.||x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
     {
       float z=.5;
       if(x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
         z=0.;
       r=d(v+vec3(0.,z,.5),v+vec3(.5,.5+z,1.),y,i,f);
       s=s||r;
     }
   if(x>=67.&&x<=82.)
     r=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,y,i,f),s=s||r;
   if(x==68.||x==69.||x==70.||x==72.||x==73.||x==74.||x==76.||x==77.||x==78.||x==80.||x==81.||x==82.)
     {
       float z=8.,n=8.;
       if(x==68.||x==70.||x==72.||x==74.||x==76.||x==78.||x==80.||x==82.)
         z=0.;
       if(x==69.||x==70.||x==73.||x==74.||x==77.||x==78.||x==81.||x==82.)
         n=16.;
       r=d(v+vec3(z,6.,7.)/16.,v+vec3(n,9.,9.)/16.,y,i,f);
       s=s||r;
       r=d(v+vec3(z,12.,7.)/16.,v+vec3(n,15.,9.)/16.,y,i,f);
       s=s||r;
     }
   if(x>=71.&&x<=82.)
     {
       float z=8.,n=8.;
       if(x>=71.&&x<=74.||x>=79.&&x<=82.)
         n=16.;
       if(x>=75.&&x<=82.)
         z=0.;
       r=d(v+vec3(7.,6.,z)/16.,v+vec3(9.,9.,n)/16.,y,i,f);
       s=s||r;
       r=d(v+vec3(7.,12.,z)/16.,v+vec3(9.,15.,n)/16.,y,i,f);
       s=s||r;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(x>=83.&&x<=86.)
     {
       vec3 z=vec3(0),n=vec3(0);
       if(x==83.)
         z=vec3(0,0,0),n=vec3(16,16,3);
       if(x==84.)
         z=vec3(0,0,13),n=vec3(16,16,16);
       if(x==86.)
         z=vec3(0,0,0),n=vec3(3,16,16);
       if(x==85.)
         z=vec3(13,0,0),n=vec3(16,16,16);
       r=d(v+z/16.,v+n/16.,y,i,f);
       s=s||r;
     }
   if(x>=87.&&x<=102.)
     {
       vec3 z=vec3(0.),n=vec3(1.);
       if(x>=87.&&x<=94.)
         {
           float h=0.;
           if(x>=91.&&x<=94.)
             h=13.;
           z=vec3(0.,h,0.)/16.;
           n=vec3(16.,h+3.,16.)/16.;
         }
       if(x>=95.&&x<=98.)
         {
           float h=13.;
           if(x==97.||x==98.)
             h=0.;
           z=vec3(0.,0.,h)/16.;
           n=vec3(16.,16.,h+3.)/16.;
         }
       if(x>=99.&&x<=102.)
         {
           float h=13.;
           if(x==99.||x==100.)
             h=0.;
           z=vec3(h,0.,0.)/16.;
           n=vec3(h+3.,16.,16.)/16.;
         }
       r=d(v+z,v+n,y,i,f);
       s=s||r;
     }
   if(x>=103.&&x<=113.)
     {
       vec3 z=vec3(0.),n=vec3(1.);
       if(x>=103.&&x<=110.)
         {
           float e=float(x)-float(103.)+1.;
           n.y=e*2./16.;
         }
       if(x==111.)
         n.y=.0625;
       if(x==112.)
         z=vec3(1.,0.,1.)/16.,n=vec3(15.,1.,15.)/16.;
       if(x==113.)
         z=vec3(1.,0.,1.)/16.,n=vec3(15.,.5,15.)/16.;
       r=d(v+z,v+n,y,i,f);
       s=s||r;
     }
   #endif
   #endif
   return s;
 }
 vec3 h(vec2 x)
 {
   vec2 v=vec2(x.xy*vec2(viewWidth,viewHeight));
   v*=1./64.;
   const vec2 i[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(x.x<2./viewWidth||x.x>1.-2./viewWidth||x.y<2./viewHeight||x.y>1.-2./viewHeight)
     ;
   v=(floor(v*64.)+.5)/64.;
   vec3 r=texture2D(noisetex,v).xyz,y=vec3(sqrt(.2),sqrt(2.),1.61803);
   r=mod(r+float(frameCounter%64)*y,vec3(1.));
   return r;
 }
 vec4 G(vec3 x,vec2 v,out float i,inout float z)
 {
   vec3 y=x;
   int s=t();
   x=clamp(x,vec3(1./s),vec3(1.-1./s));
   if(distance(x,y)>.005/s)
     z=1.;
   float r=dot(abs(x-y),vec3(1.));
   #ifdef MC_GL_VENDOR_ATI
   #endif
   vec2 m=d(x,s);
   m+=v.xy*(1./vec2(4096));
   m=m*2.-1.;
   i=r;
   return vec4(m,i,1.);
 }
 void main()
 {
   gl_Position=ftransform();
   vTexcoord=gl_MultiTexCoord0;
   vMCEntity=mc_Entity.x;
   vViewPos=gl_ModelViewMatrix*gl_Vertex;
   vec4 v=gl_Position;
   v=shadowProjectionInverse*v;
   v=shadowModelViewInverse*v;
   v.xyz+=cameraPosition.xyz;
   vec3 x=v.xyz;
   vMaterialIDs=30.;
   float z=0.,s=0.f,i=0.f;
   if(mc_Entity.x==8||mc_Entity.x==9)
     z=1.f;
   if(mc_Entity.x==95||mc_Entity.x==160||mc_Entity.x==90||mc_Entity.x==165||mc_Entity.x==79)
     i=1.f;
   if(mc_Entity.x==79)
     s=1.f;
   if(mc_Entity.x==18.||mc_Entity.x==161.f||mc_Entity.x==914.f||mc_Entity.x==915.f||mc_Entity.x==919.f)
     vMaterialIDs=36.;
   if(mc_Entity.x==79.f||mc_Entity.x==174.f)
     vMaterialIDs=37.;
   if(mc_Entity.x==50||mc_Entity.x==52||mc_Entity.x==76||mc_Entity.x==75||mc_Entity.x==74||mc_Entity.x==72)
     vMaterialIDs=241.;
   if(mc_Entity.x==10||mc_Entity.x==11)
     vMaterialIDs=241.;
   if(mc_Entity.x==89||mc_Entity.x==124||mc_Entity.x==10||mc_Entity.x==11||mc_Entity.x==169||mc_Entity.x==91)
     vMaterialIDs=31.;
   if(mc_Entity.x==51||mc_Entity.x==53)
     vMaterialIDs=241.;
   #ifdef GLOWING_LAPIS_LAZULI_BLOCK
   if(mc_Entity.x==22)
     vMaterialIDs=31.;
   #endif
   #ifdef GLOWING_REDSTONE_BLOCK
   if(mc_Entity.x==152)
     vMaterialIDs=31.;
   #endif
   #ifdef GLOWING_EMERALD_BLOCK
   if(mc_Entity.x==133)
     vMaterialIDs=31.;
   #endif
   if(mc_Entity.x==95||mc_Entity.x==160)
     vMaterialIDs=240.;
   if(mc_Entity.x==188)
     vMaterialIDs=32.;
   if(mc_Entity.x==189)
     vMaterialIDs=33.;
   if(mc_Entity.x==190)
     vMaterialIDs=34.;
   if(mc_Entity.x==191)
     vMaterialIDs=35.;
   vec3 y=gl_Normal,r=normalize(gl_NormalMatrix*y);
   if(abs(vMaterialIDs-2.)<.1)
     y=vec3(0.,1.,0.);

   // === Shadow-synced vegetation wave (fix: shadows stayed static while
   // grass/flowers/leaves/wheat/vines waved in the wind) ===
   // Applies the SAME displacement formula as the vegetation wind system in
   // gbuffers_terrain.vsh, so the shadow a plant casts sways together with the
   // plant itself.
   //
   // Deliberately an EXPLICIT whitelist (short grass/fern/dead bush, flowers,
   // double plants/tall grass, saplings, mushrooms, wheat/crops, beetroots,
   // sweet berry bush, glow berries, leaves, vines - NOT sugar cane, which
   // is fully static, block and shadow both) rather than the
   // angled-normal GENERAL_GRASS_FIX heuristic gbuffers_terrain.vsh uses for
   // lighting purposes - that heuristic also matches stairs, slabs, fences,
   // trapdoors, doors etc., which would make every angled block's shadow sway
   // too. Every block not on this list is left completely untouched.
   // Speed is controlled separately by WIND_EFFECT so it can be
   // tuned to match VEG_WIND_TIME_SCALE.
   {
     float shadowGrassWeight=0.;
     if(mc_Entity.x==31.||mc_Entity.x==38.f||mc_Entity.x==37.f||mc_Entity.x==1925.f||mc_Entity.x==1920.f||mc_Entity.x==1921.f
       ||mc_Entity.x>=904.f&&mc_Entity.x<=913.f&&mc_Entity.x!=911.f||mc_Entity.x==106.f)
       shadowGrassWeight=1.; // original + modern vegetation/custom wind IDs (911 twisting/weeping vines, 916 big dripleaf excluded - no wind sway)
     if(mc_Entity.x==175.f||mc_Entity.x==PW_UPPER_HALF_ID)
       shadowGrassWeight=1.; // double plants: tall grass, large fern, flowers (175 = lower half, 208 = upper half)
     if(mc_Entity.x==6.f)
       shadowGrassWeight=1.; // all legacy saplings
     if(mc_Entity.x==30.f)
       shadowGrassWeight=1.; // cobweb
     if(mc_Entity.x==39.f||mc_Entity.x==40.f)
       shadowGrassWeight=1.; // brown/red mushroom
     // Sugar cane (mc_Entity.x==83) is deliberately excluded here too - it
     // doesn't move in the visible pass (gbuffers_terrain.vsh) anymore
     // either, so its shadow must stay static as well.
     if(mc_Entity.x==59.)
       shadowGrassWeight=1.; // wheat/crops
     if(mc_Entity.x==207.f)
       shadowGrassWeight=1.; // beetroots (all growth stages)
     if(mc_Entity.x==917.f)
       shadowGrassWeight=1.; // sweet berry bush
     if(mc_Entity.x==918.f)
       shadowGrassWeight=1.; // glow berries (cave vines/cave vines plant)

     // Plants handled by the Photon-style wind (lib/PhotonWind.inc) use that
     // instead of the old sway below, exactly like gbuffers_terrain.vsh.
     int pwPlantClass=PwPlantClass(mc_Entity.x);
     if(pwPlantClass>0)
       shadowGrassWeight=0.;

     bool shadowIsLeaves=false;
     if(mc_Entity.x==18.||mc_Entity.x==161.f||mc_Entity.x==914.f||mc_Entity.x==915.f)
     {
       if(gl_Color.x>.999&&gl_Color.y>.999&&gl_Color.z>.999)
         ;
       else
          shadowIsLeaves=true;
       if(abs(gl_Color.x-gl_Color.y)>.001||abs(gl_Color.x-gl_Color.z)>.001||abs(gl_Color.y-gl_Color.z)>.001)
         shadowIsLeaves=true;
     }
     // Modern leaf blocks use explicit entity IDs; do not depend on the
     // shadow-pass vertex color to identify them.
     if(mc_Entity.x==914.f||mc_Entity.x==915.f)
       shadowIsLeaves=true;

     // === Photon waving plants (shadow pass, same maths as gbuffers_terrain.vsh) ===
     #ifdef WIND_EFFECT_ENABLED
     if(pwPlantClass>0)
     {
       bool pwIsTopVertex=vTexcoord.y<mc_midTexCoord.y;
       float pwSkylight=clamp(gl_MultiTexCoord1.y/240.0,0.,1.);
       v.xyz+=PwPlantDisplacement(x,pwIsTopVertex,pwSkylight,pwPlantClass);
     }
     #endif

     if(shadowGrassWeight>0.||mc_Entity.x==106.0f||shadowIsLeaves)
     {
       vec4 shadowLmcoord=gl_TextureMatrix[1]*gl_MultiTexCoord1;
       float shadowBlockLightX=clamp(shadowLmcoord.x*33.05f/32.f-.0328125f,0.f,1.f);
       float shadowBlockLightY=clamp(shadowLmcoord.y*33.75f/32.f-.0328125f,0.f,1.f);
       float shadowLightWeight=clamp(max(shadowBlockLightX,shadowBlockLightY),0.,1.);

       float shadowWindTime=WIND_TIME*WIND_EFFECT;

       #ifdef WIND_EFFECT_ENABLED
       float shadowWindMasterFactor=1.0f;
       #else
       float shadowWindMasterFactor=0.0f;
       #endif

       #ifdef OUTDOOR_WIND_ONLY
       // Same skylight gating as gbuffers_terrain.vsh: shadowBlockLightY above
       // is this vertex's own raw sky light (0 = no sky/indoors, 1 = open sky),
       // independent of block light, so a torch-lit room still reads indoors.
       float shadowOutdoorWindFactor=smoothstep(0.0f,1.0f,shadowBlockLightY)*shadowWindMasterFactor;
       float shadowOutdoorWindSpeed=mix(0.2f,1.0f,smoothstep(0.0f,1.0f,shadowBlockLightY));
       shadowWindTime*=shadowOutdoorWindSpeed;
       #else
       float shadowOutdoorWindFactor=shadowWindMasterFactor;
       #endif

       vec3 shadowWindWorldPos=v.xyz;

       vec2 shadowAddAngleLight=vec2(0.);
       vec2 shadowAddAngleHeavy=vec2(0.);
       vec2 shadowAddAngle=vec2(0.);

       vec3 shadowAddPn0=shadowWindWorldPos;
       shadowAddPn0.x-=shadowWindTime/3.0f;

       vec3 shadowAddStoch=texture2D(noisetex,shadowAddPn0.xz/64.0f).xyz;
       vec3 shadowAddStochLarge=texture2D(noisetex,shadowWindWorldPos.xz/(64.0f*6.0f)).xyz;

       vec3 shadowAddPn=shadowWindWorldPos;
       shadowAddPn.x*=2.0f;
       shadowAddPn.x-=shadowWindTime*15.0f;
       shadowAddPn.z*=8.0f;

       vec3 shadowAddStochLargeMoving=texture2D(noisetex,shadowAddPn.xz/(64.0f*10.0f)).xyz;

       vec3 shadowAddP=shadowWindWorldPos;
       shadowAddP.x+=sin(shadowAddP.z/2.0f);
       shadowAddP.xz+=shadowAddStochLarge.rg*5.0f;

       float shadowAddWindStrength=mix(0.85f,1.0f,rainStrength);
       float shadowAddWindRandom=shadowAddStochLargeMoving.x;
       shadowAddWindRandom=pow(shadowAddWindRandom,mix(2.0f,1.0f,rainStrength));
       shadowAddWindStrength*=mix(shadowAddWindRandom,0.5f,rainStrength*0.25f);

       float shadowAddHeavyAF=8.0f,shadowAddHeavyAL=0.9f,shadowAddHeavyAR=13.0f,shadowAddHeavyAA=15.0f,shadowAddHeavyAO=15.0f;
       float shadowAddHeavyLF=6.732f,shadowAddHeavyLL=1.274f,shadowAddHeavyLR=1.0f,shadowAddHeavyLA=6.0f,shadowAddHeavyLO=0.0f;
       float shadowAddLightAF=5.5f,shadowAddLightAL=1.1f,shadowAddLightAR=21.0f,shadowAddLightAA=5.0f,shadowAddLightAO=5.0f;
       float shadowAddLightLF=5.9732f,shadowAddLightLL=1.174f,shadowAddLightLR=0.0f,shadowAddLightLA=1.0f,shadowAddLightLO=0.0f;

       float shadowAddCrossfade=clamp(shadowAddWindStrength*2.0f-1.0f,0.0f,1.0f);
       float shadowAddLightFade=clamp(shadowAddWindStrength*2.0f,0.2f,1.0f);

       shadowAddAngleLight.x+=sin(shadowWindTime*shadowAddLightAF-shadowAddP.x*shadowAddLightAL+shadowAddStoch.x*shadowAddLightAR)*shadowAddLightAA+shadowAddLightAO;
       shadowAddAngleLight.y+=sin(shadowWindTime*shadowAddLightLF-shadowAddP.x*shadowAddLightLL+shadowAddStoch.x*shadowAddLightLR)*shadowAddLightLA+shadowAddLightLO;

       shadowAddAngleHeavy.x+=sin(shadowWindTime*shadowAddHeavyAF-shadowAddP.x*shadowAddHeavyAL+shadowAddStoch.x*shadowAddHeavyAR)*shadowAddHeavyAA+shadowAddHeavyAO;
       shadowAddAngleHeavy.y+=sin(shadowWindTime*shadowAddHeavyLF-shadowAddP.x*shadowAddHeavyLL+shadowAddStoch.x*shadowAddHeavyLR)*shadowAddHeavyLA+shadowAddHeavyLO;

       shadowAddAngle=mix(shadowAddAngleLight*shadowAddLightFade,shadowAddAngleHeavy,vec2(shadowAddCrossfade));
       shadowAddAngle*=2.0f;

       float shadowVineWeight=(mc_Entity.x==106.0f)?clamp(vTexcoord.t,0.0f,1.0f):1.0f;
       float shadowVegetationWindWeight=shadowGrassWeight*shadowVineWeight*shadowLightWeight*shadowOutdoorWindFactor;

       v.x+=sin((shadowAddAngle.x/180.0f)*3.141579f)*shadowVegetationWindWeight*0.5f;
       v.z+=sin((shadowAddAngle.y/180.0f)*3.141579f)*shadowVegetationWindWeight*0.5f;
       v.y+=(cos(((shadowAddAngle.x+shadowAddAngle.y)/180.0f)*3.141579f)-1.0f)*shadowVegetationWindWeight*0.5f;

       // Wheat/crop secondary sway (matches gbuffers_terrain.vsh)
       if(mc_Entity.x==59.0f&&vTexcoord.t<0.35f)
       {
         float shadowWheatSpeed=0.28f;
         float shadowWheatMagnitude=sin((shadowWindTime*20.0f*3.14159265f/28.0f)+shadowWindWorldPos.x+shadowWindWorldPos.z)*0.12f+0.02f;
         shadowWheatMagnitude*=shadowGrassWeight*0.2f;
         shadowWheatMagnitude*=shadowLightWeight;
         shadowWheatMagnitude*=shadowOutdoorWindFactor;

         float shadowWheatD0=sin(shadowWindTime*20.0f*3.14159265f/(122.0f*shadowWheatSpeed))*3.0f-1.5f+shadowWindWorldPos.z;
         float shadowWheatD1=sin(shadowWindTime*20.0f*3.14159265f/(152.0f*shadowWheatSpeed))*3.0f-1.5f+shadowWindWorldPos.x;
         float shadowWheatD2=sin(shadowWindTime*20.0f*3.14159265f/(122.0f*shadowWheatSpeed))*3.0f-1.5f+shadowWindWorldPos.x;
         float shadowWheatD3=sin(shadowWindTime*20.0f*3.14159265f/(152.0f*shadowWheatSpeed))*3.0f-1.5f+shadowWindWorldPos.z;

         v.x+=sin((shadowWindTime*20.0f*3.14159265f/(28.0f*shadowWheatSpeed))+(v.x+shadowWheatD0)*0.1f+(shadowWindWorldPos.z+shadowWheatD1)*0.1f)*shadowWheatMagnitude;
         v.z+=sin((shadowWindTime*20.0f*3.14159265f/(28.0f*shadowWheatSpeed))+(shadowWindWorldPos.z+shadowWheatD2)*0.1f+(v.x+shadowWheatD3)*0.1f)*shadowWheatMagnitude;
       }

       // Leaf flutter (matches gbuffers_terrain.vsh leaves block)
       // pwPlantClass==0 excludes leaves now handled by the Photon-style
       // wind above (id 18/914/915), so they don't get both animations.
       if(shadowIsLeaves&&pwPlantClass==0&&vTexcoord.t<1.90f&&vTexcoord.t>-1.0f)
       {
         float shadowLeavesSpeed=0.25f;
         float shadowLeavesMagnitude=(sin(shadowWindWorldPos.y+shadowWindWorldPos.x+shadowWindTime*20.0f*3.14159265f/(28.0f*shadowLeavesSpeed))*0.15f+0.15f)*0.30f*shadowLightWeight*0.2f;
         shadowLeavesMagnitude*=shadowLightWeight;
         shadowLeavesMagnitude*=shadowOutdoorWindFactor;

         float shadowLeavesD0=sin(shadowWindTime*20.0f*3.14159265f/(112.0f*shadowLeavesSpeed))*3.0f-1.5f;
         float shadowLeavesD1=sin(shadowWindTime*20.0f*3.14159265f/(142.0f*shadowLeavesSpeed))*3.0f-1.5f;
         float shadowLeavesD2=sin(shadowWindTime*20.0f*3.14159265f/(132.0f*shadowLeavesSpeed))*3.0f-1.5f;
         float shadowLeavesD3=sin(shadowWindTime*20.0f*3.14159265f/(122.0f*shadowLeavesSpeed))*3.0f-1.5f;

         v.x+=sin((shadowWindTime*20.0f*3.14159265f/(18.0f*shadowLeavesSpeed))+(-shadowWindWorldPos.x+shadowLeavesD0)*1.6f+(shadowWindWorldPos.z+shadowLeavesD1)*1.6f)*shadowLeavesMagnitude*(1.0f+rainStrength);
         v.z+=sin((shadowWindTime*20.0f*3.14159265f/(17.0f*shadowLeavesSpeed))+(shadowWindWorldPos.z+shadowLeavesD2)*1.6f+(-shadowWindWorldPos.x+shadowLeavesD3)*1.6f)*shadowLeavesMagnitude*(1.0f+rainStrength);
         v.y+=sin((shadowWindTime*20.0f*3.14159265f/(11.0f*shadowLeavesSpeed))+shadowWindWorldPos.z+shadowLeavesD2+shadowWindWorldPos.x+shadowLeavesD3)*(shadowLeavesMagnitude/2.0f)*(1.0f+rainStrength);
       }

       // Vine sway (matches gbuffers_terrain.vsh vine block)
       if(mc_Entity.x==106.0f&&pwPlantClass==0)
       {
         float shadowVineSpeed=0.32f;
         float shadowVineTime=shadowWindTime*20.0f*3.14159265f/28.0f;

         float shadowVineFade=clamp(vTexcoord.t,0.0f,1.0f);
         shadowVineFade*=shadowLightWeight;
         shadowVineFade*=shadowOutdoorWindFactor;

         float shadowVineNoise=texture2D(noisetex,shadowWindWorldPos.xz/32.0f).r;

         float shadowVineSway=sin(shadowVineTime/shadowVineSpeed+shadowWindWorldPos.x*1.7f+shadowWindWorldPos.z*1.3f+shadowVineNoise*6.2831853f)*0.035f;
         float shadowVineSway2=cos(shadowVineTime/(shadowVineSpeed*1.35f)+shadowWindWorldPos.z*1.4f-shadowWindWorldPos.x*1.1f+shadowVineNoise*4.0f)*0.025f;

         vec2 shadowVineDir=normalize(gl_Normal.xz+vec2(1e-5f));
         v.xz+=shadowVineDir*(shadowVineSway+shadowVineSway2)*shadowVineFade;

         v.y+=sin(shadowVineTime/(shadowVineSpeed*1.7f)+shadowWindWorldPos.x*1.2f+shadowWindWorldPos.z*1.5f)*0.018f*shadowVineFade;
       }
     }
   }

   iqqNEmzHrA=mc_midTexCoord.xy;
   vColor=gl_Color;
   NfBQQONGIL=0.;
   {
     vec2 f;
     // Use the pre-wind position (x) for the RT voxel/geometry encoding, not the
     // wind-swayed v.xyz. The voxel grid this feeds must stay stable per-block;
     // if it uses the swayed position the voxel cell (after floor()) hops between
     // neighboring cells every frame as the plant oscillates, causing the
     // "tetris"/flickering block artifact in RT reflections. Only the final
     // shadow-map depth (below) should use the swayed position.
     vec3 m=d(x,gl_Normal.xyz,vTexcoord.xy,mc_midTexCoord.xy,at_tangent,mc_Entity,NfBQQONGIL,f);
     #ifdef FOLIAGE_VOXEL_LIGHT_FIX
     // === Fix: grass/flowers next to a light source dim it ===
     // d() above snaps this vertex into its voxel cell by nudging it inward along
     // the face normal, which only makes sense for a real axis-aligned cube face.
     // Grass, flowers, tall grass, saplings, mushrooms, sugar cane, wheat/crops,
     // vines and cobwebs are diagonal "cross" quads, so that nudge can land them
     // in the WRONG voxel cell - most noticeably a neighboring light-emitting
     // block's cell, whose bright voxel color then gets overwritten by the
     // plant's much darker one, dimming the light. These blocks were never solid
     // occluders in the voxel grid anyway, so simply excluding them (same as
     // water/ice/glass/carpet a few lines up, inside d()) removes the corruption.
     // Same block-ID whitelist as the vegetation wind sway further down this file.
     if(mc_Entity.x==31.||mc_Entity.x==38.f||mc_Entity.x==37.f||mc_Entity.x==1925.f||mc_Entity.x==1920.f||mc_Entity.x==1921.f
       ||mc_Entity.x>=904.f&&mc_Entity.x<=913.f||mc_Entity.x==916.f||mc_Entity.x==920.f||mc_Entity.x==106.f||mc_Entity.x==911.f
       ||mc_Entity.x==175.f||mc_Entity.x==PW_UPPER_HALF_ID||mc_Entity.x==6.f||mc_Entity.x==30.f||mc_Entity.x==39.f||mc_Entity.x==40.f
       ||mc_Entity.x==83.f||mc_Entity.x==59.f||mc_Entity.x==207.f||mc_Entity.x==917.f||mc_Entity.x==918.f)
       NfBQQONGIL=1.;
     #endif
     if(mc_Entity.x>255)
       vMaterialIDs=mc_Entity.x-255.+39.;
     m=floor(m);
     m-=cameraPosition.xyz;
     int h=t();
     m=n(m,h);
     MHKfCXtBYe=m*h;
     zoZckPcbco=G(m,f,GgEUdJcgVD,NfBQQONGIL);
     if(mc_Entity.x==51||mc_Entity.x==53||mc_Entity.x==50||mc_Entity.x==52||mc_Entity.x==76)
       GgEUdJcgVD+=.9;
   }
   {
     v.xyz-=cameraPosition.xyz;
     v=shadowModelView*v;
     v=shadowProjection*v;
     gl_Position=v;
     float f=sqrt(gl_Position.x*gl_Position.x+gl_Position.y*gl_Position.y),e=1.f-SHADOW_MAP_BIAS+f*SHADOW_MAP_BIAS;
     gl_Position.xy*=.95f/e;
     gl_Position.xy*=.5;
     gl_Position.xy+=.5;
     if(z>.5)
       gl_Position.y-=1.;
     if(i>.5)
       gl_Position.x-=1.;
     gl_Position.z=mix(gl_Position.z,.5,.8);
     RrnawHBGMh=gl_Position;
     gl_FrontColor=gl_Color;
   }
 };



