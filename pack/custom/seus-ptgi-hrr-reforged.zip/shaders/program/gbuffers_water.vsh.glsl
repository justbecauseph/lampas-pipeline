



attribute vec4 mc_Entity;

out vec4 color;
out vec4 texcoord;
out vec4 lmcoord;
out vec3 worldPosition;
out vec4 vertexPos;
out vec4 viewPos;
out vec4 preDownscaleProjPos;

out vec3 normal;
out vec3 globalNormal;
out vec3 tangent;
out vec3 binormal;
out vec3 viewVector;
out vec3 viewVector2;
out float distance;


out float isWater;
out float isIce;
out float isStainedGlass;
out float isSlime;
out vec2 blockLight;

out vec3 worldNormal;

#include "/lib/Uniforms.inc"
#include "/lib/Common.inc"
#include "/lib/PhysicsOcean.inc"

#ifdef PHYSICS_OCEAN
	#ifdef PHYSICS_OCEAN_V2
		in float physics_waviness;
	#endif
	out vec3 physics_localPosition;
	out float physics_localWaviness;
#endif


void main() {

	// Vertex position used for everything below. With Physics Mod the flat ocean mesh
	// is displaced by the Physics wave function; otherwise it is the raw vertex.
	vec4 vertexIn = gl_Vertex;
	#ifdef PHYSICS_OCEAN
		#ifdef PHYSICS_OCEAN_V2
			physics_localWaviness = physics_waviness;
			float physicsBaseWaveHeight = physics_waveHeight(gl_Vertex.xz, PHYSICS_ITERATIONS_OFFSET, physics_localWaviness, physics_gameTime);
			float physicsRippleHeight = physics_rippleVertexHeight(gl_Vertex.xz);
			physics_localPosition = vec3(gl_Vertex.x, gl_Vertex.y + physicsBaseWaveHeight + physicsRippleHeight, gl_Vertex.z);
		#else
			physics_localWaviness = texelFetch(physics_waviness, ivec2(gl_Vertex.xz) - physics_textureOffset, 0).r;
			physics_localPosition = gl_Vertex.xyz + vec3(0.0, physics_waveHeight(gl_Vertex.xz, PHYSICS_ITERATIONS_OFFSET, physics_localWaviness, physics_gameTime), 0.0);
		#endif
		vertexIn = vec4(physics_localPosition, 1.0);
	#endif

	// FIX: default to static (isStainedGlass) instead of defaulting to 0/0/0/0.
	// Previously, only explicitly-listed block IDs (79 ice, 95 stained glass,
	// 160 stained glass pane, 90 nether portal) were marked isStainedGlass=1.
	// Plain glass (id 20) and plain glass panes (id 102) matched NONE of the
	// checks below, so they fell through with isWater=0 AND isStainedGlass=0,
	// which made them use the animated water-wave normal (GetWavesNormal) in
	// gbuffers_water.fsh -- i.e. plain glass rippled like water.
	// Defaulting isStainedGlass to 1.0 and only clearing it for confirmed
	// translucent block that isn't water gets the static per-texel normal.
	isWater = 0.0;
	isIce = 0.0;
	isStainedGlass = 1.0;
	isSlime = 0.0;

	if(mc_Entity.x == 8)
	{
		isWater = 1.0;
		isStainedGlass = 0.0;
	}
	
		 vertexPos = vertexIn;

	// if (mc_Entity.x == 1971.0f)
	// {
	// 	isWater = 1.0f;
	// }
	
	// if (mc_Entity.x == 8 || mc_Entity.x == 9) {
	// 	isWater = 1.0f;
	// }

	if (mc_Entity.x == 165)
	{
		isSlime = 1.0;
		isStainedGlass = 0.0;
	}

	#ifdef PHYSICS_OCEAN
		// The Physics Mod ocean program only ever draws the water surface.
		isWater = 1.0;
		isIce = 0.0;
		isStainedGlass = 0.0;
		isSlime = 0.0;
	#endif


	
		
	vec4 worldPos = gbufferModelViewInverse * gl_ModelViewMatrix * vertexIn;
	vec4 position = worldPos;

	worldPosition.xyz = worldPos.xyz + cameraPosition.xyz;
	viewPos = gbufferModelView * position;

	vec4 localPosition = gl_ModelViewMatrix * vertexIn;

	distance = length(localPosition.xyz);

	gl_Position = gl_ProjectionMatrix * (gbufferModelView * position);



	FinalVertexTransformTAA(gl_Position, preDownscaleProjPos);


	gl_Position.z -= 0.0001;

	
	color = gl_Color;
	
	texcoord = gl_TextureMatrix[0] * gl_MultiTexCoord0;

	lmcoord = gl_TextureMatrix[1] * gl_MultiTexCoord1;
	
	blockLight.x = clamp((lmcoord.x * 33.05f / 32.0f) - 1.05f / 32.0f, 0.0f, 1.0f);
	blockLight.y = clamp((lmcoord.y * 33.75f / 32.0f) - 1.05f / 32.0f, 0.0f, 1.0f);

	gl_FogFragCoord = gl_Position.z;


	
	
	normal = normalize(gl_NormalMatrix * gl_Normal);
	globalNormal = normalize(gl_Normal);

	if (gl_Normal.x > 0.5) {
		//  1.0,  0.0,  0.0
		tangent  = normalize(gl_NormalMatrix * vec3( 0.0,  0.0, -1.0));
		binormal = normalize(gl_NormalMatrix * vec3( 0.0, -1.0,  0.0));
	} else if (gl_Normal.x < -0.5) {
		// -1.0,  0.0,  0.0
		tangent  = normalize(gl_NormalMatrix * vec3( 0.0,  0.0,  1.0));
		binormal = normalize(gl_NormalMatrix * vec3( 0.0, -1.0,  0.0));
	} else if (gl_Normal.y > 0.5) {
		//  0.0,  1.0,  0.0
		tangent  = normalize(gl_NormalMatrix * vec3( 1.0,  0.0,  0.0));
		binormal = normalize(gl_NormalMatrix * vec3( 0.0,  0.0,  1.0));
	} else if (gl_Normal.y < -0.5) {
		//  0.0, -1.0,  0.0
		tangent  = normalize(gl_NormalMatrix * vec3( 1.0,  0.0,  0.0));
		binormal = normalize(gl_NormalMatrix * vec3( 0.0,  0.0,  1.0));
	} else if (gl_Normal.z > 0.5) {
		//  0.0,  0.0,  1.0
		tangent  = normalize(gl_NormalMatrix * vec3( 1.0,  0.0,  0.0));
		binormal = normalize(gl_NormalMatrix * vec3( 0.0, -1.0,  0.0));
	} else if (gl_Normal.z < -0.5) {
		//  0.0,  0.0, -1.0
		tangent  = normalize(gl_NormalMatrix * vec3(-1.0,  0.0,  0.0));
		binormal = normalize(gl_NormalMatrix * vec3( 0.0, -1.0,  0.0));
	}
	
	mat3 tbnMatrix = mat3(tangent.x, binormal.x, normal.x,
                          tangent.y, binormal.y, normal.y,
                          tangent.z, binormal.z, normal.z);

	viewVector = (gl_ModelViewMatrix * vertexIn).xyz;
	viewVector2 = normalize(viewVector);
	viewVector = normalize(tbnMatrix * viewVector);


	worldNormal = gl_Normal.xyz;

	
}
