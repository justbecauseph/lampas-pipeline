#version 330 compatibility

// Physics Mod ocean program (Physics Mod v2 shader support)
#define PHYSICS_OCEAN
#define PHYSICS_OCEAN_V2

#include "/program/gbuffers_water.fsh.glsl"
