#version 330 compatibility
#extension GL_ARB_gpu_shader5 : enable

/*
 _______ _________ _______  _______  _
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/



#include "lib/Uniforms.inc"
#include "lib/Common.inc"


// #define DEPTH_OF_FIELD //Toggle Depth of Field (DoF).
#define DOF_STRENGTH 0.3 //Adjust the maximum Blur Amount. [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define BIAS 0.15 //Adjust the Aperture. Bigger values cause a shallower Depth of Field. [0.04 0.06 0.08 0.10 0.12 0.14 0.15 0.16 0.18 0.20 0.22 0.24]

vec3 GetDoFColorTexture(vec2 coord) {
	return pow(texture2DLod(colortex0, coord, 0).rgb, vec3(2.2));
}

vec3 DepthOfField(vec2 baseUV, float dofblur) {
	vec2 aspectcorrect = vec2(1.0, aspectRatio) * 1.5;

	vec3 col = vec3(0.0);
	col += GetDoFColorTexture(baseUV);

	col += GetDoFColorTexture(baseUV + (vec2( 0.0,0.4 )*aspectcorrect) * dofblur);
	col += GetDoFColorTexture(baseUV + (vec2( 0.15,0.37 )*aspectcorrect) * dofblur);
	col += GetDoFColorTexture(baseUV + (vec2( 0.29,0.29 )*aspectcorrect) * dofblur);
	col += GetDoFColorTexture(baseUV + (vec2( -0.37,0.15 )*aspectcorrect) * dofblur);
	col += GetDoFColorTexture(baseUV + (vec2( 0.4,0.0 )*aspectcorrect) * dofblur);
	col += GetDoFColorTexture(baseUV + (vec2( 0.37,-0.15 )*aspectcorrect) * dofblur);
	col += GetDoFColorTexture(baseUV + (vec2( 0.29,-0.29 )*aspectcorrect) * dofblur);
	col += GetDoFColorTexture(baseUV + (vec2( -0.15,-0.37 )*aspectcorrect) * dofblur);
	col += GetDoFColorTexture(baseUV + (vec2( 0.0,-0.4 )*aspectcorrect) * dofblur);
	col += GetDoFColorTexture(baseUV + (vec2( -0.15,0.37 )*aspectcorrect) * dofblur);
	col += GetDoFColorTexture(baseUV + (vec2( -0.29,0.29 )*aspectcorrect) * dofblur);
	col += GetDoFColorTexture(baseUV + (vec2( 0.37,0.15 )*aspectcorrect) * dofblur);
	col += GetDoFColorTexture(baseUV + (vec2( -0.4,0.0 )*aspectcorrect) * dofblur);
	col += GetDoFColorTexture(baseUV + (vec2( -0.37,-0.15 )*aspectcorrect) * dofblur);
	col += GetDoFColorTexture(baseUV + (vec2( -0.29,-0.29 )*aspectcorrect) * dofblur);
	col += GetDoFColorTexture(baseUV + (vec2( 0.15,-0.37 )*aspectcorrect) * dofblur);

	col += GetDoFColorTexture(baseUV + (vec2( 0.15,0.37 )*aspectcorrect) * dofblur*0.9);
	col += GetDoFColorTexture(baseUV + (vec2( -0.37,0.15 )*aspectcorrect) * dofblur*0.9);
	col += GetDoFColorTexture(baseUV + (vec2( 0.37,-0.15 )*aspectcorrect) * dofblur*0.9);
	col += GetDoFColorTexture(baseUV + (vec2( -0.15,-0.37 )*aspectcorrect) * dofblur*0.9);
	col += GetDoFColorTexture(baseUV + (vec2( -0.15,0.37 )*aspectcorrect) * dofblur*0.9);
	col += GetDoFColorTexture(baseUV + (vec2( 0.37,0.15 )*aspectcorrect) * dofblur*0.9);
	col += GetDoFColorTexture(baseUV + (vec2( -0.37,-0.15 )*aspectcorrect) * dofblur*0.9);
	col += GetDoFColorTexture(baseUV + (vec2( 0.15,-0.37 )*aspectcorrect) * dofblur*0.9);

	col += GetDoFColorTexture(baseUV + (vec2( 0.29,0.29 )*aspectcorrect) * dofblur*0.7);
	col += GetDoFColorTexture(baseUV + (vec2( 0.4,0.0 )*aspectcorrect) * dofblur*0.7);
	col += GetDoFColorTexture(baseUV + (vec2( 0.29,-0.29 )*aspectcorrect) * dofblur*0.7);
	col += GetDoFColorTexture(baseUV + (vec2( 0.0,-0.4 )*aspectcorrect) * dofblur*0.7);
	col += GetDoFColorTexture(baseUV + (vec2( -0.29,0.29 )*aspectcorrect) * dofblur*0.7);
	col += GetDoFColorTexture(baseUV + (vec2( -0.4,0.0 )*aspectcorrect) * dofblur*0.7);
	col += GetDoFColorTexture(baseUV + (vec2( -0.29,-0.29 )*aspectcorrect) * dofblur*0.7);
	col += GetDoFColorTexture(baseUV + (vec2( 0.0,0.4 )*aspectcorrect) * dofblur*0.7);

	col += GetDoFColorTexture(baseUV + (vec2( 0.29,0.29 )*aspectcorrect) * dofblur*0.4);
	col += GetDoFColorTexture(baseUV + (vec2( 0.4,0.0 )*aspectcorrect) * dofblur*0.4);
	col += GetDoFColorTexture(baseUV + (vec2( 0.29,-0.29 )*aspectcorrect) * dofblur*0.4);
	col += GetDoFColorTexture(baseUV + (vec2( 0.0,-0.4 )*aspectcorrect) * dofblur*0.4);
	col += GetDoFColorTexture(baseUV + (vec2( -0.29,0.29 )*aspectcorrect) * dofblur*0.4);
	col += GetDoFColorTexture(baseUV + (vec2( -0.4,0.0 )*aspectcorrect) * dofblur*0.4);
	col += GetDoFColorTexture(baseUV + (vec2( -0.29,-0.29 )*aspectcorrect) * dofblur*0.4);
	col += GetDoFColorTexture(baseUV + (vec2( 0.0,0.4 )*aspectcorrect) * dofblur*0.4);

	vec3 color = col/41;
	color = pow(color, vec3(1.0 / 2.2));

	return color;
}


/////////////////////////CONFIGURABLE VARIABLES////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////CONFIGURABLE VARIABLES////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


/////////////////////////END OF CONFIGURABLE VARIABLES/////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////END OF CONFIGURABLE VARIABLES/////////////////////////////////////////////////////////////////////////////////////////////////////////////




///////////////////////// UNDERWATER DISTORTION /////////////////////////////////
// Screen-space refraction effect applied only while the camera is underwater.
// Choose the distortion strength from the shader options menu.

#define UNDERWATER_DISTORTION_STRENGTH 0.00150 // [0.00000 0.00050 0.00100 0.00150 0.00200 0.00250 0.00300 0.00350 0.00400]
#define UNDERWATER_DISTORTION_SPEED 1.5 // [0.5 1.0 1.5 2.0 2.5 3.0 3.5 4.0]

vec2 GetUnderwaterDistortion(vec2 uv)
{
    float t = frameTimeCounter * UNDERWATER_DISTORTION_SPEED;

    vec2 wave;

    wave.x = sin(uv.y * 85.0 + t * 2.0) * 0.55
           + sin(uv.y * 145.0 - t * 1.35) * 0.25;

    wave.y = cos(uv.x * 95.0 - t * 1.7) * 0.55
           + cos(uv.x * 160.0 + t * 1.15) * 0.25;

    vec2 noiseUV = uv * 3.5
                 + vec2(t * 0.025, -t * 0.018);

    vec2 ripple = texture2D(noisetex, noiseUV).rg * 2.0 - 1.0;

    return uv + (wave + ripple * 0.30)
               * UNDERWATER_DISTORTION_STRENGTH;
}

///////////////////////// CAMERA SWAY /////////////////////////////////
// Gentle handheld-style drift + tilt of the final resolved image. Runs after
// TAA has already resolved the frame, so (unlike a per-vertex offset) it is
// not averaged away by temporal accumulation - it's simply visible every frame.

// #define CAMERA_SWAY // If enabled, the view drifts and tilts gently instead of staying perfectly locked
#define CAMERA_SWAY_SPEED 1.0 // Speed of the camera sway [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0]
#define CAMERA_SWAY_AMOUNT 0.0080 // How far the view drifts sideways/up-down, in screen-space UV units [0.0010 0.0015 0.0020 0.0025 0.0030 0.0035 0.0040 0.0050 0.0060 0.0070 0.0080 0.0100 0.0125 0.0150 0.0200]
#define CAMERA_SWAY_TILT 0.0060 // How far the view rolls/tilts, in radians [0.0000 0.0010 0.0020 0.0030 0.0040 0.0050 0.0060 0.0080 0.0100 0.0125 0.0150]

vec2 GetCameraSway(vec2 uv)
{
	float t = frameTimeCounter * CAMERA_SWAY_SPEED;

	//Several sines at incommensurate frequencies/phases per axis so the drift
	//never repeats on a simple beat and reads as organic, handheld motion
	//rather than a metronome-like up/down bob.
	vec2 offset;
	offset.x = sin(t * 0.63 + 0.0) * 0.55 + sin(t * 1.31 + 1.7) * 0.30 + sin(t * 0.27 + 3.1) * 0.15;
	offset.y = sin(t * 0.87 + 0.9) * 0.60 + sin(t * 1.97 + 2.4) * 0.25 + sin(t * 0.41 + 5.2) * 0.15;
	offset *= CAMERA_SWAY_AMOUNT;

	float roll = (sin(t * 0.51 + 0.6) * 0.6 + sin(t * 1.13 + 2.2) * 0.4) * CAMERA_SWAY_TILT;

	vec2 centered = uv - 0.5;
	float s = sin(roll);
	float c = cos(roll);
	centered = mat2(c, -s, s, c) * centered;

	return centered + 0.5 + offset;
}

///////////////////////// SCREEN RAIN DROPS /////////////////////////////////
// Individually-animated rain drops on the lens while it is raining. Each
// grid cell runs its own independent lifecycle instead of the whole pattern
// scrolling as one image: a drop clings near the top with a little surface
// jitter, then breaks free and accelerates downward (cubic ease-in, like
// gravity) leaving a stretched trail, fades out, and the cycle repeats with
// a new random phase. Purely a screen-space UV warp - no geometry or extra
// render targets needed. Toggle with SCREEN_RAIN_DROPS in the shader
// options menu.

#define SCREEN_RAIN_DROPS // Adds individually-animated rain drops that cling, then fall down the screen while it's raining
#define RAIN_DROPS_AMOUNT 50.0 // Roughly how many drops fit across the screen [15.0 20.0 25.0 30.0 35.0 40.0 50.0 60.0 80.0]
#define RAIN_DROPS_SIZE 0.50 // Size of each drop [0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.70 0.80]
#define RAIN_DROPS_STRENGTH 0.0250 // How strongly each drop bends the image behind it [0.0050 0.0100 0.0150 0.0200 0.0220 0.0250 0.0300 0.0400 0.0500]
#define RAIN_DROPS_SPEED 1.3 // How fast each drop accelerates downward once it breaks free - only affects that individual fall, not a global scroll [0.4 0.6 0.8 1.0 1.3 1.6 2.0 2.5 3.0]
#define RAIN_DROPS_CLING_TIME 0.6 // Fraction of each drop's cycle spent clinging near the top before it falls [0.2 0.3 0.4 0.5 0.6 0.65 0.7 0.8]
#define RAIN_DROPS_BUILDUP 1.0 // How gradually drops build up when rain starts [0.0 0.25 0.5 0.75 1.0 1.5 2.0]
#define RAIN_DROPS_INDOOR_SKYLIGHT 0.98 // Require almost full Minecraft SKY light (15/15) before lens drops are visible [0.90 0.92 0.94 0.96 0.98 1.00]

float RainDropsHash(vec2 p)
{
	p = fract(p * vec2(123.34, 456.21));
	p += dot(p, p + 45.32);
	return fract(p.x * p.y);
}

// Cubic ease-in: near-zero rate of change at the start, steep at the end -
// approximates a drop accelerating under gravity rather than gliding at a
// constant speed.
float RainDropsEaseIn(float x)
{
	return x * x * x;
}

// Screen-space raindrop distortion. The grid itself is fixed in screen
// space (it never scrolls) - each cell just hashes its own drop and plays
// out that drop's cling/fall/fade cycle on a loop with a per-cell phase
// offset, so neighbouring drops fall at different moments instead of the
// whole field moving together like a scrolled texture.
vec2 GetRainDropsDistortion(vec2 uv)
{
	vec2 aspect = vec2(viewWidth / viewHeight, 1.0);
	vec2 warpedUV = uv;

	for (int layer = 0; layer < 2; layer++)
	{
		float layerScale = RAIN_DROPS_AMOUNT * (layer == 0 ? 1.0 : 0.65);
		vec2 grid = uv * aspect * layerScale;

		vec2 cell = floor(grid);
		vec2 cellUV = fract(grid) - 0.5;

		vec2 dropSeed = cell + float(layer) * 17.0;
		float occupied = RainDropsHash(dropSeed);

		// rainStrength ramps up as Minecraft transitions into rain. Instead of
		// spawning the whole field immediately, use that transition as a spawn
		// budget: the first drop appears almost immediately and the rest are
		// introduced progressively as the rain gets stronger.
		float rainBuild = smoothstep(0.001, 1.0, rainStrength);
		rainBuild = pow(rainBuild, max(RAIN_DROPS_BUILDUP, 0.05));
		float layerCells = layerScale * layerScale;
		float activeFraction = max(1.0 / max(layerCells, 1.0), rainBuild * 0.50);

		// One deterministic seed cell is always the first drop. This avoids
		// the annoying "rain started but nothing spawned yet" case.
		vec2 firstCell = floor(vec2(layerScale * (0.37 + 0.08 * float(layer)), layerScale * (0.61 - 0.06 * float(layer))));
		float firstDrop = float(cell.x == firstCell.x && cell.y == firstCell.y);
		bool spawnDrop = (firstDrop > 0.5) || (occupied < activeFraction);

		if (spawnDrop)
		{
			// Each drop gets its own cycle length and phase, so drops
			// across the screen fall at different, unsynchronised moments
			float cycleDur = mix(1.4, 3.2, RainDropsHash(dropSeed + 0.41)) / max(RAIN_DROPS_SPEED, 0.05);
			float phase = RainDropsHash(dropSeed + 0.53) * cycleDur;
			float t = mod(frameTimeCounter + phase, cycleDur) / cycleDur; // 0..1 through this drop's life

			// Every time this cell's drop finishes a cling/fall cycle and loops
			// back to the start, re-roll where in the cell it forms. Without
			// this, dropCenterX/startY only depend on the cell's static seed,
			// so the "same" drop keeps clinging and falling from the exact
			// same spot forever. cycleIndex counts which loop of this cell's
			// drop we're currently in, and folding it into the position seed
			// gives each successive drop a fresh, unrepeated spawn point while
			// leaving the timing (cycleDur/phase) untouched.
			float cycleIndex = floor((frameTimeCounter + phase) / cycleDur);
			vec2 posSeed = dropSeed + cycleIndex * vec2(13.73, 7.19);

			float dropCenterX = (RainDropsHash(posSeed + 0.11) - 0.5) * 0.5;
			float startY = 0.35 - RainDropsHash(posSeed + 0.61) * 0.15; // near the top of the cell
			float endY = startY - 0.85; // falls from the top toward the bottom

			float dropCenterY;
			float speedFactor; // 0 = clinging/static, ramps toward 1 as the fall accelerates
			float alpha;       // fades the drop in as it forms and out right before it resets

			if (t < RAIN_DROPS_CLING_TIME)
			{
				// Clinging phase: sits almost still with a faint surface
				// jitter, like surface tension holding it against the glass
				float jt = t / max(RAIN_DROPS_CLING_TIME, 0.0001);
				float wobble = sin(jt * 20.0 + phase * 10.0) * 0.010 * (1.0 - jt);
				dropCenterY = startY + wobble;
				speedFactor = 0.0;
				alpha = smoothstep(0.0, 0.12, jt);
			}
			else
			{
				// Falling phase: cubic ease-in from the cling point to the
				// bottom of the cell, so it starts slow and drops fast
				float ft = (t - RAIN_DROPS_CLING_TIME) / max(1.0 - RAIN_DROPS_CLING_TIME, 0.0001);
				float eased = RainDropsEaseIn(ft);
				dropCenterY = mix(startY, endY, eased);
				speedFactor = ft * ft;
				alpha = 1.0 - smoothstep(0.82, 1.0, ft);
			}

			vec2 dropCenter = vec2(dropCenterX, dropCenterY);
			float dropRadius = 0.5 * RAIN_DROPS_SIZE * (0.6 + RainDropsHash(posSeed + 0.33) * 0.6);

			// Stretch the drop vertically as it speeds up, like a real
			// droplet elongating on glass under gravity, then measure
			// distance in that stretched space
			vec2 delta = cellUV - dropCenter;
			vec2 wakeDelta = delta; // keep the wake in un-stretched screen space
			delta.y /= (1.0 + speedFactor * 1.8);
			float dist = length(delta);

			if (dist < dropRadius && alpha > 0.001)
			{
				vec2 dir = delta / max(dist, 0.0001);
				float falloff = 1.0 - dist / dropRadius;
				// Smoothstep-shaped lens bulge: near-clear at the very
				// center, bending hardest close to the drop's edge
				float bulge = falloff * falloff * (3.0 - 2.0 * falloff);
				warpedUV -= (dir * bulge * RAIN_DROPS_STRENGTH * alpha) / aspect;
			}

			// Water wake: as the droplet falls from TOP to BOTTOM, the
			// wake remains ABOVE/behind it and keeps distorting the image
			// after the main drop has already moved past.
			if (t >= RAIN_DROPS_CLING_TIME && alpha > 0.001)
			{
				float trailLen = dropRadius * (2.5 + speedFactor * 5.0);
				float behindY = wakeDelta.y; // positive = above the falling drop
				float trail = clamp(behindY / trailLen, 0.0, 1.0);
				float trailWidth = 1.0 - smoothstep(dropRadius * 0.15, dropRadius * 0.85, abs(wakeDelta.x));
				trail *= trailWidth;
				trail *= 1.0 - smoothstep(0.55, 1.0, trail);
				trail *= smoothstep(0.0, 0.12, speedFactor);

				warpedUV.y += trail * RAIN_DROPS_STRENGTH * 0.45 * alpha;
			}
		}
	}

	return warpedUV;
}


//Sway/underwater-distortion move the sample point off the pixel grid, and a
//plain bilinear fetch softens the image slightly whenever that happens (it's
//blending between texels instead of reading one cleanly). This is the
//standard 5-tap Catmull-Rom bicubic resample: it reconstructs a sharper
//result at sub-pixel offsets than bilinear, and lands exactly back on the
//bilinear result whenever the offset is zero (sway disabled), so it doesn't
//change anything about the image except recovering that lost sharpness.
vec3 SampleColorSharp(sampler2D tex, vec2 uv, vec2 texSize)
{
	vec2 samplePos = uv * texSize;
	vec2 texPos1 = floor(samplePos - 0.5) + 0.5;
	vec2 f = samplePos - texPos1;

	vec2 w0 = f * (-0.5 + f * (1.0 - 0.5 * f));
	vec2 w1 = 1.0 + f * f * (-2.5 + 1.5 * f);
	vec2 w2 = f * (0.5 + f * (2.0 - 1.5 * f));
	vec2 w3 = f * f * (-0.5 + 0.5 * f);

	vec2 w12 = w1 + w2;
	vec2 offset12 = w2 / w12;

	vec2 texPos0 = (texPos1 - 1.0) / texSize;
	vec2 texPos3 = (texPos1 + 2.0) / texSize;
	vec2 texPos12 = (texPos1 + offset12) / texSize;

	vec3 result = vec3(0.0);
	result += texture2D(tex, vec2(texPos0.x,  texPos0.y)).rgb  * w0.x  * w0.y;
	result += texture2D(tex, vec2(texPos12.x, texPos0.y)).rgb  * w12.x * w0.y;
	result += texture2D(tex, vec2(texPos3.x,  texPos0.y)).rgb  * w3.x  * w0.y;

	result += texture2D(tex, vec2(texPos0.x,  texPos12.y)).rgb * w0.x  * w12.y;
	result += texture2D(tex, vec2(texPos12.x, texPos12.y)).rgb * w12.x * w12.y;
	result += texture2D(tex, vec2(texPos3.x,  texPos12.y)).rgb * w3.x  * w12.y;

	result += texture2D(tex, vec2(texPos0.x,  texPos3.y)).rgb  * w0.x  * w3.y;
	result += texture2D(tex, vec2(texPos12.x, texPos3.y)).rgb  * w12.x * w3.y;
	result += texture2D(tex, vec2(texPos3.x,  texPos3.y)).rgb  * w3.x  * w3.y;

	return max(result, vec3(0.0));
}



///////////////////////// FINAL SHARPENING /////////////////////////////////
// Final sharpening mode.
// 0 = Post Sharpening, 1 = CAS, 2 = RCAS.
// CAS and RCAS use a fixed maximum amount of 1.0.
// Only the selected path is compiled/executed.
#define SHARPENING_MODE 2 // [0 1 2]
// 0 = Post Sharpening
// 1 = CAS
// 2 = RCAS

#define FSR_RCAS_LIMIT (0.25 - (1.0 / 16.0))

float RCAS_SafeRcp(float x)
{
	float ax = max(abs(x), 0.000001);
	return 1.0 / ax * sign(x);
}

vec3 ApplyRCAS(sampler2D tex, vec2 uv, vec2 texelSize, float amount)
{
	if (amount <= 0.00001)
		return texture2D(tex, uv).rgb;

	ivec2 resolution = ivec2(
		texelSize.x > 0.0 ? floor(1.0 / texelSize.x + 0.5) : 1.0,
		texelSize.y > 0.0 ? floor(1.0 / texelSize.y + 0.5) : 1.0
	);
	ivec2 ip = ivec2(floor(uv * vec2(resolution)));
	ip = clamp(ip, ivec2(0), resolution - ivec2(1));

	float sharpnessStops = (1.0 - clamp(amount, 0.0, 1.0)) * 4.0;
	float sharpness = exp2(-sharpnessStops);

	vec3 b = texelFetch(tex, clamp(ip + ivec2(0, -1), ivec2(0), resolution - ivec2(1)), 0).rgb;
	vec3 d = texelFetch(tex, clamp(ip + ivec2(-1, 0), ivec2(0), resolution - ivec2(1)), 0).rgb;
	vec3 e = texelFetch(tex, ip, 0).rgb;
	vec3 f = texelFetch(tex, clamp(ip + ivec2(1, 0), ivec2(0), resolution - ivec2(1)), 0).rgb;
	vec3 h = texelFetch(tex, clamp(ip + ivec2(0, 1), ivec2(0), resolution - ivec2(1)), 0).rgb;

	float bL = b.b * 0.5 + (b.r * 0.5 + b.g);
	float dL = d.b * 0.5 + (d.r * 0.5 + d.g);
	float eL = e.b * 0.5 + (e.r * 0.5 + e.g);
	float fL = f.b * 0.5 + (f.r * 0.5 + f.g);
	float hL = h.b * 0.5 + (h.r * 0.5 + h.g);

	float nz = 0.25 * bL + 0.25 * dL + 0.25 * fL + 0.25 * hL - eL;
	float lumaRange = max(max(bL, dL), max(max(eL, fL), hL))
					- min(min(bL, dL), min(min(eL, fL), hL));
	nz = clamp(abs(nz) / max(lumaRange, 0.000001), 0.0, 1.0);
	nz = -0.5 * nz + 1.0;

	vec3 mn4 = min(min(b, d), min(f, h));
	vec3 mx4 = max(max(b, d), max(f, h));

	vec3 hitMin = min(mn4, e) / max(4.0 * mx4, vec3(0.000001));
	vec3 hitMax = (vec3(1.0) - max(mx4, e))
				* vec3(
					RCAS_SafeRcp(4.0 * mn4.r - 4.0),
					RCAS_SafeRcp(4.0 * mn4.g - 4.0),
					RCAS_SafeRcp(4.0 * mn4.b - 4.0)
				);

	vec3 lobeRGB = max(-hitMin, hitMax);
	float lobe = max(
		-FSR_RCAS_LIMIT,
		min(max(max(lobeRGB.r, lobeRGB.g), lobeRGB.b), 0.0)
	);
	lobe *= sharpness;
	lobe *= nz;

	float rcpL = 1.0 / (4.0 * lobe + 1.0);
	vec3 result = (lobe * (b + d + f + h) + e) * rcpL;

	return clamp(result, vec3(0.0), vec3(1.0));
}

float CAS_Saturate(float x)
{
	return clamp(x, 0.0, 1.0);
}

vec3 CAS_Saturate(vec3 x)
{
	return clamp(x, vec3(0.0), vec3(1.0));
}

vec3 ApplyAMD_CAS(sampler2D tex, vec2 uv, vec2 texelSize, float amount)
{
	if (amount <= 0.00001)
		return texture2D(tex, uv).rgb;

	float peak = -1.0 / mix(8.0, 5.0, CAS_Saturate(amount));

	vec2 oX = vec2(texelSize.x, 0.0);
	vec2 oY = vec2(0.0, texelSize.y);

	vec3 b = texture2D(tex, clamp(uv - oY, vec2(0.0), vec2(1.0))).rgb;
	vec3 d = texture2D(tex, clamp(uv - oX, vec2(0.0), vec2(1.0))).rgb;
	vec3 e = texture2D(tex, uv).rgb;
	vec3 f = texture2D(tex, clamp(uv + oX, vec2(0.0), vec2(1.0))).rgb;
	vec3 h = texture2D(tex, clamp(uv + oY, vec2(0.0), vec2(1.0))).rgb;

	vec3 mn = min(min(d, e), min(f, min(b, h)));
	vec3 mx = max(max(d, e), max(f, max(b, h)));

	vec3 rcpMx = 1.0 / max(mx, vec3(0.000001));
	vec3 amp = CAS_Saturate(min(mn, vec3(1.0) - mx) * rcpMx);
	amp = sqrt(amp);

	float w = amp.g * peak;
	float rcpWeight = 1.0 / (1.0 + 4.0 * w);

	vec3 casColor = (b * w + d * w + f * w + h * w + e) * rcpWeight;
	casColor = clamp(casColor, vec3(0.0), vec3(1.0));

	return mix(e, casColor, CAS_Saturate(amount));
}

vec3 ApplyFinalSharpening(sampler2D tex, vec2 uv, vec2 texelSize)
{
	#if SHARPENING_MODE == 0
		// Original post sharpening / reconstruction path.
		return SampleColorSharp(tex, uv, 1.0 / texelSize);
	#elif SHARPENING_MODE == 1
		// AMD CAS at fixed maximum strength.
		return ApplyAMD_CAS(tex, uv, texelSize, 1.0);
	#else
		// AMD RCAS at fixed maximum strength.
		return ApplyRCAS(tex, uv, texelSize, 1.0);
	#endif
}

///////////////////////// SKY BLUR /////////////////////////////////////
// A slight blur applied to the sky only (clouds, sun, moon, stars): softens whatever grain is left in the clouds.
// 0 = off. The value is the blur radius in pixels (1.0 = a plain 3x3 gaussian, which is a subtle softening).
#define SKY_DEPTH_THRESHOLD 0.999999 // Only real sky (cleared depth = 1.0) counts as sky. The old 0.9999 also matched far-away buildings/terrain, which then got blurred.
#define SKY_BLUR 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 4.0 5.0]

// Wide gaussian look (sigma = 1.5 steps) folded into 3x3 = 9 bilinear fetches (neighbouring gaussian taps merged into one
// fetch placed between them), so the cost stays close to a plain 3x3 blur.
//
// Skyline safety (fixes the moving outlines): it only averages other SKY pixels, and a tap near the skyline is rejected if
// its bilinear footprint touches terrain (no dark/bright outline). Near the skyline the blur also fades out smoothly
// towards the original pixel, so the terrain edge is never replaced by sky colour. Taps outside the screen are dropped.
// When the whole footprint is open sky (almost everywhere) the depth tests are skipped.
bool SkyBlurIsSky(vec2 uv)
{
	return texture2DLod(depthtex0, DownscaleTexcoord(uv), 0.0).x > SKY_DEPTH_THRESHOLD;
}

// A tap is only usable if its centre and its bilinear footprint (+-0.75 px) are all open sky.
bool SkyBlurTapIsSky(vec2 o, vec2 texelSize)
{
	vec2 h = texelSize * 0.75;
	return SkyBlurIsSky(o) && SkyBlurIsSky(o + vec2(h.x, h.y)) && SkyBlurIsSky(o + vec2(-h.x, h.y))
	    && SkyBlurIsSky(o + vec2(h.x, -h.y)) && SkyBlurIsSky(o + vec2(-h.x, -h.y));
}

vec3 ApplySkyBlur(sampler2D tex, vec2 uv, vec2 texelSize, float radius)
{
	const float edgeMargin = 0.0005;
	const float spatialTotal = 3.69 * 3.69; // sum of all 9 spatial weights

	float stepPx = min(radius * 1.25, 2.0);
	vec2 stepUV = texelSize * stepPx;
	vec2 E = stepUV * 1.5 + texelSize;

	// Is the full footprint open sky and on-screen? (8 depth taps around the kernel border.)
	bool interior = uv.x - E.x > edgeMargin && uv.y - E.y > edgeMargin && uv.x + E.x < 1.0 - edgeMargin && uv.y + E.y < 1.0 - edgeMargin;
	if (interior)
	{
		interior = SkyBlurIsSky(uv + vec2(-E.x, -E.y)) && SkyBlurIsSky(uv + vec2(0.0, -E.y)) && SkyBlurIsSky(uv + vec2(E.x, -E.y))
		        && SkyBlurIsSky(uv + vec2(-E.x, 0.0))                                      && SkyBlurIsSky(uv + vec2(E.x, 0.0))
		        && SkyBlurIsSky(uv + vec2(-E.x, E.y))  && SkyBlurIsSky(uv + vec2(0.0, E.y))  && SkyBlurIsSky(uv + vec2(E.x, E.y));
	}

	vec3 c0 = texture2DLod(tex, uv, 0.0).rgb;
	vec3 sum = vec3(0.0);
	float wsum = 0.0;
	float spatialValid = 0.0;

	for (int y = 0; y < 3; y++)
	{
		for (int x = 0; x < 3; x++)
		{
			float px = (x == 0) ? -1.5 : ((x == 1) ? 0.0 : 1.5);
			float py = (y == 0) ? -1.5 : ((y == 1) ? 0.0 : 1.5);
			float w = ((x == 1) ? 1.0 : 1.345) * ((y == 1) ? 1.0 : 1.345);
			vec2 o = uv + vec2(px, py) * stepUV;

			if (!interior && !(x == 1 && y == 1))
			{
				if (o.x < edgeMargin || o.y < edgeMargin || o.x > 1.0 - edgeMargin || o.y > 1.0 - edgeMargin)
					continue;
				if (!SkyBlurTapIsSky(o, texelSize))
					continue;
			}

			spatialValid += w;

			vec3 c = (x == 1 && y == 1) ? c0 : texture2DLod(tex, o, 0.0).rgb;
			sum += c * w;
			wsum += w;
		}
	}

	vec3 blurred = sum / max(wsum, 1e-5);

	// Fade the blur out towards the skyline so the terrain edge keeps its original pixels.
	float skyness = interior ? 1.0 : smoothstep(0.65, 1.0, spatialValid / spatialTotal);
	return mix(c0, blurred, skyness);
}

///////////////////////// STAR MASK (stars are never blurred) //////////////////////////////
// Procedural / Photon stars (CUSTOM_STARS): the exact star lattice used by RenderNightStars() is recomputed here from the
// pixel's view direction (same maths, same hash), so the mask lands exactly on the stars. Only runs on sky pixels at night.
// Default (vanilla SEUS) stars: gbuffers_skybasic flags the star fragments in the unused z channel of the motion buffer
// (colortex8), which is read back here. No extra render pass, no extra buffer, nothing added to any other pass.
// Returns 1.0 on a star (keep the pixel sharp), 0.0 elsewhere, with a short soft edge.
#ifdef STARS

#define SKY_BLUR_KEEP_STARS
#define STAR_FLAG_VALUE 16.0 // must match gbuffers_skybasic.fsh

// 0.0 = sky blur allowed, 1.0 = this pixel belongs to a star
float SkyBlurStarMask(vec2 uv)
{
	// Stars only exist while the sun is low (same fade-in as RenderNightStars).
	vec3 lightDir = normalize((shadowModelViewInverse * vec4(0.0, 0.0, 1.0, 0.0)).xyz);
	vec3 sunDir = lightDir * -sign(sunAngle * 2.0 - 1.0);
	if (-sunDir.y < -0.2 || rainStrength > 0.999)
		return 0.0;

	float mask = 0.0;

	#ifdef CUSTOM_STARS
	{
		// View direction of this pixel, exactly like the sky pass.
		vec4 vp = gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, 1.0, 1.0);
		vec3 l = normalize((gbufferModelViewInverse * vec4(vp.xyz / vp.w, 0.0)).xyz);
		if (isEyeInWater > 0)
			l = refract(l, vec3(0.0, -1.0, 0.0), 1.3);

		mat3 spin = (sunAngle < 0.5)
			? mat3(shadowModelViewInverse)
			: mat3(-shadowModelViewInverse[0].xyz, shadowModelViewInverse[1].xyz, -shadowModelViewInverse[2].xyz);
		vec3 dir = l * spin;

		float cutoff = 1.0 - 0.05 * STARS_COVERAGE * smoothstep(-0.2, 0.05, -sunDir.y);

		vec2 puv = (dir.xy / (abs(dir.z) + length(dir.xy)) + 41.21 * sign(dir.z)) * 600.0;
		vec2 pos = abs(puv) + 33.3 * vec2(greaterThanEqual(puv, vec2(0.0)));
		vec2 base = floor(pos);

		// Every star sits on a lattice point and is a bump 1 cell wide. Check the lattice points within 2 cells (4x4),
		// which covers the whole bump plus the little spread the temporal upscaling adds around it.
		for (int j = -1; j <= 2; j++)
		{
			for (int i = -1; i <= 2; i++)
			{
				vec2 L = base + vec2(float(i), float(j));
				float s = saturate((StarCellRandom(L).x - cutoff) / (1.0 - cutoff));
				float s2 = s * s;
				float s4 = s2 * s2;
				float s8 = s4 * s4;
				float s16 = s8 * s8;                       // same sharpening as StarInCell()
				float d = length(pos - L);
				float m = s16 * (1.0 - smoothstep(1.4, 2.0, d));
				mask = max(mask, m);
			}
		}
		// Any star bright enough to ever show up (even a very faint one) counts; dimmer than that is invisible anyway.
		mask = smoothstep(0.0003, 0.002, mask);
	}
	#else
	{
		// Vanilla stars: look for the flag in a 3x3 block of the half-res scene buffer around this pixel
		// (4 bilinear taps, each one covering 2x2 texels).
		vec2 c = DownscaleTexcoord(uv);
		vec2 h = vec2(0.5 / viewWidth, 0.5 / viewHeight);
		float f = texture2DLod(colortex8, c + vec2( h.x,  h.y), 0.0).z
		        + texture2DLod(colortex8, c + vec2(-h.x,  h.y), 0.0).z
		        + texture2DLod(colortex8, c + vec2( h.x, -h.y), 0.0).z
		        + texture2DLod(colortex8, c + vec2(-h.x, -h.y), 0.0).z;
		mask = saturate(f * 0.5); // a single flagged texel gives >= 4 on at least one tap
	}
	#endif

	return mask;
}

#endif // STARS

in vec4 texcoord;


/////////////////////////MAIN//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////MAIN//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void main() {

	vec2 sampleUV = texcoord.st;

	#ifdef CAMERA_SWAY
	sampleUV = GetCameraSway(sampleUV);
	#endif

	if (isEyeInWater > 0) {
		sampleUV = GetUnderwaterDistortion(sampleUV);
	}

	#ifdef SCREEN_RAIN_DROPS
	if (isEyeInWater == 0 && rainStrength > 0.001) {
		// Minecraft's smoothed sky-light at the player's eyes is a useful
		// shader-side indoor/cave signal. Keep a little hysteresis-like
		// softness so drops fade out instead of popping when entering a house.
		// eyeBrightnessSmooth.y is Minecraft's smoothed SKY light level
		// at the camera, in the 0..240 lightmap range. This is preferable
		// to testing final screen brightness: torches can be bright indoors
		// while the sky light is still zero.
		float skyLight = clamp(float(eyeBrightnessSmooth.y) / 240.0, 0.0, 1.0);

		// Minecraft sky light is 15 levels (240 in the shader lightmap).
		// A roof/block above the player reduces this below full sky light.
		// Require almost the full 15/15 value so houses and caves suppress
		// the lens drops even when some skylight leaks in through windows.
		float indoorFade = smoothstep(
			max(RAIN_DROPS_INDOOR_SKYLIGHT - 0.08, 0.0),
			RAIN_DROPS_INDOOR_SKYLIGHT,
			skyLight
		);

		if (indoorFade > 0.001) {
			sampleUV = mix(texcoord.st, GetRainDropsDistortion(sampleUV), indoorFade);
		}
	}
	#endif

	sampleUV = clamp(sampleUV, vec2(0.001), vec2(0.999));

	vec3 color = texture2D(colortex0, sampleUV).rgb;
	// color = GammaToLinear(color);

	#ifndef SKIP_AA
	// Final AMD sharpening. RCAS/CAS are mutually exclusive compile-time paths.
	// CAS / RCAS never touch the sky (clouds, sun, moon, stars): sharpening only amplifies the cloud noise.
	// Sky pixels keep the unsharpened colour. (The sharpened colour is still computed first so that CAS's
	// texture2D calls stay in uniform control flow.)
	vec3 unsharpenedColor = color;
	color = ApplyFinalSharpening(colortex0, sampleUV, vec2(1.0 / viewWidth, 1.0 / viewHeight));
	#if SHARPENING_MODE != 0
	if (texture2DLod(depthtex0, DownscaleTexcoord(sampleUV), 0.0).x > SKY_DEPTH_THRESHOLD) {
		color = unsharpenedColor;
	}
	#endif
	#endif

	// Slight blur on the sky only.
	#if CLOUD_MODE >= 3 // only the Photon (3) and Bliss (4) profiles; the default (2) and cloudless (1) profiles never blur
	if (SKY_BLUR > 0.0 && texture2DLod(depthtex0, DownscaleTexcoord(sampleUV), 0.0).x > SKY_DEPTH_THRESHOLD) {
		// Stars (vanilla and Photon/procedural) are masked out exactly and keep their original pixels.
		#ifdef SKY_BLUR_KEEP_STARS
		float starKeep = SkyBlurStarMask(sampleUV);
		if (starKeep < 0.999)
			color = mix(ApplySkyBlur(colortex0, sampleUV, vec2(1.0 / viewWidth, 1.0 / viewHeight), SKY_BLUR), color, starKeep);
		#else
		color = ApplySkyBlur(colortex0, sampleUV, vec2(1.0 / viewWidth, 1.0 / viewHeight), SKY_BLUR);
		#endif
	}
	#endif

	#ifdef DEPTH_OF_FIELD
	float depth = texture2D(depthtex0, sampleUV * 0.5).x;
	if(depth < 0.7) {
		depth += 0.45f;
	}
	float dofblur = (depth - texture2D(depthtex0, vec2(0.25)).x) * BIAS * DOF_STRENGTH;
	vec3 dofColor = DepthOfField(sampleUV, dofblur);
	color = mix(dofColor, color, saturate(exp(-dofblur * 1000.0)));
	#endif

	gl_FragColor = vec4(color, 1.0);
}
